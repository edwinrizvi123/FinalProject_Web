(function($) {
  'use strict';
  function showCompactMenu() {
    $('body').addClass('sidebar-mini');
  }
})(jQuery);
