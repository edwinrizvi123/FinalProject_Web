<?php
class Data_model extends CI_Model {
	function __construct(){
		parent::__construct();
		$this->load->database();
	}

	public function getAllProduct(){
		$query = $this->db->get('jasa');
		return $query->result(); 
	}

	public function getAllUser(){
		$query = $this->db->get('user');
		return $query->result(); 
	}

	public function getAllAdmin(){
		$query = $this->db->get('admin');
		return $query->result(); 
	}

	function jumlah_user(){
        $query = $this->db->query("SELECT * FROM user");
        $jumlah_data = $query->num_rows();
        return $jumlah_data;
    }

	public function insertData($file){
		return $this->db->insert('jasa', $file);
	}

	public function delete_data($id){
	    return $this->db->delete('jasa', array("id" => $id));
	}

	public function update_data($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}

	function jumlah_jasa(){
        $query = $this->db->query("SELECT * FROM jasa");
        $jumlah_data = $query->num_rows();
        return $jumlah_data;
    }

	public function insert_user($table, $data){
        return $this->db->insert($table, $data);
    }

    // Cek Email Register
    public function cek_email($email){
        $query = $this->db->get_where('user', array('email' => $email));
        if(empty($query->row_array())){
            return true;
        } else {
            return false;
        }
    }

    public function delete_user($id){
	    return $this->db->delete('user', array("id" => $id));
	}

	function edit_user($where,$table){		
		return $this->db->get_where($table,$where);
	}

	public function update_user($where,$data,$table){
		$this->db->where($where);
		$this->db->update($table,$data);
	}

	public function insert_admin($table, $data){
        return $this->db->insert($table, $data);
    }

    public function cek_email_admin($email){
        $query = $this->db->get_where('admin', array('email' => $email));
        if(empty($query->row_array())){
            return true;
        } else {
            return false;
        }
    }

    public function find_jasa($id){
		$result = $this->db->where('id', $id)
							->limit(1)
							->get('jasa');
		if($result->num_rows() > 0){
			return $result->row();
		}else{
			return array();
		}
	}

	public function pesan($table, $data){
        $this->db->insert($table, $data);

    }

	public function pesan1(){
		

				$nama_depan = $this->input->post('fName');
	            $nama_belakang = $this->input->post('lName');
	            $email = $this->input->post('email');
	            $phone = $this->input->post('phone');
	            $alamat = $this->input->post('alamat');
	            $area = $this->input->post('area');
	            $catatan = $this->input->post('catatan');
	            $instruksi = $this->input->post('instruksi');
	            $id = $this->input->post('id');

	            foreach ($this->cart->contents() as $item) {
		            $data = [
		                'nm_depan' => $nama_depan,
		                'nm_belakang' => $nama_belakang,
		                'telepon' => $phone,
		                'alamat' => $alamat,
		                'area' => $area,
		                'catatan' => $catatan,
		                'instruksi' => $instruksi,
		                'tanggal' => date("Y-m-d H:i:s"),
		                'tenggat' => date('Y-m-d H:i:s', mktime(date('H'), date('i'), date('s'), date('m'), date('d') + 1, date('Y'))),
		                'id' => $id,
		                'id_jasa' 		=> $item['id'],
						'nama_jasa' 	=> $item['name'],
						'jumlah' 		=> $item['qty'],
						'harga'			=> $item['price'],
						'jenis'			=> $item['options'],
		            ];

		        }

		            $this->db->insert('invoice', $data);

		            foreach ($this->cart->contents() as $item) {
		            	$invoice = [
							'id_pesanan' 	=> $id,
							'id_jasa' 		=> $item['id'],
							'nama_jasa' 	=> $item['name'],
							'jumlah' 		=> $item['qty'],
							'harga'			=> $item['price'],
							'jenis'			=> $item['options'],
							'tanggal' => date("Y-m-d H:i:s"),
						];
						$this->db->insert('pesanan', $invoice);
	            	}
	            	return TRUE;
	   }
	            

    public function getAllInvoice(){
		$query = $this->db->get('invoice');
		return $query->result(); 
	}

	public function id_pesanan(){
		  $this->db->select('RIGHT(invoice.id,2) as id', FALSE);
		  $this->db->order_by('id','DESC');    
		  $this->db->limit(1);    
		  $query = $this->db->get('invoice');  //cek dulu apakah ada sudah ada kode di tabel.    
		  if($query->num_rows() <> 0){      
			   //cek kode jika telah tersedia    
			   $data = $query->row();      
			   $kode = intval($data->id) + 1; 
		  }
		  else{      
			   $kode = 1;  //cek jika kode belum terdapat pada table
		  }
		  	
		  	$total=$this->cart->total();
			$tgl=date('dmY'); 
			$batas = str_pad($kode, 4, "0", STR_PAD_LEFT);    
			$kodetampil = "JK".$kode.$tgl.$batas;  //format kode
			return $kodetampil;
		  	  
		 }

		function detail_pesanan($where,$table){	
			return $this->db->get_where($table,$where);
		
		}

		// function getDetailPesanan($where,$table){
		// 	// $query = $this->db->get_where($table,['id_pesanan' => '$where']);
		// 	$query = $this->db->select('id')->from($table)->where('id_pesanan', '$where')->get();
  //   		return $query->row();

 	// 	}

		public function getAllPesanan(){
			$query = $this->db->get('pesanan');
			return $query->result(); 
		}

		function total_pesanan(){
        	$query = $this->db->query("SELECT * FROM pesanan");
        	$jumlah_data = $query->num_rows();
        	return $jumlah_data;
	    }

	    function total_invoice(){
        	$query = $this->db->query("SELECT * FROM invoice");
        	$jumlah_data = $query->num_rows();
        	return $jumlah_data;
    }

    	function total_harga(){
    		$this->db->select_sum('harga');
    		// $total_pendapatan = $total_harga * $total_jasa;
    		$query = $this->db->get('pesanan');
    		if($query->num_rows()>0)
		   {
		     return $query->row()->harga;
		   }
		   else
		   {
		     return 0;
		   }
    	}

    	function total_terjual(){
    		$this->db->select_sum('jumlah');
    		// $total_pendapatan = $total_harga * $total_jasa;
    		$query = $this->db->get('pesanan');
    		if($query->num_rows()>0)
		   {
		     return $query->row()->jumlah;
		   }
		   else
		   {
		     return 0;
		   }
    	}




	}

?>