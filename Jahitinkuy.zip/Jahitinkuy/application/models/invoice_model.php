<?php

class invoice_model extends CI_Model{

public function ambil_id_pesanan($id_invoice)
 	{
 		$result = $this->db->where('id_pesanan', $id_invoice)->get('pesanan');
 		if($result->num_rows() > 0){
 			return $result->result();
 		}else {
 			return false;
 		}
 	}

public function ambil_id_invoice($id_invoice)
 	{
 		$result = $this->db->where('id', $id_invoice)->limit(1)->get('invoice');
 		if($result->num_rows() > 0){
 			return $result->row();
 		}else {
 			return false;
 		}
 	}


public function delete_order($id){
	   return $this->db->delete('pesanan', array('id' => $id));
	}

}

?>