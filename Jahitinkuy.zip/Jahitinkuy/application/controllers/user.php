<?php
class User extends CI_Controller{

public function index(){
  $this->load->view('user/v_home');
}

public function login(){
    	$this->load->library('session');
    	$this->load->view('user/v_login');
	}

	public function signup(){
    $this->load->library('session');
    $this->load->view('user/v_register');
	}

	function register(){
		$this->load->library('form_validation');
    $this->form_validation->set_rules('fName', 'Nama','required|min_length[1]|max_length[30]');
		$this->form_validation->set_rules('email', 'Email','trim|required|min_length[1]|max_length[30]|valid_email|callback_cek_email');
    $this->form_validation->set_rules('password', 'Password','required|min_length[8]');
    $this->form_validation->set_rules('confirm-password', 'Konfirmasi Password', 'required|matches[password]');
		$this->form_validation->set_rules('bday', 'Tanggal lahir','trim|required');
    $this->form_validation->set_rules('gender', 'Jenis Kelamin','required');


        if($this->form_validation->run()==true){

            $nama_depan = $this->input->post('fName');
            $nama_belakang = $this->input->post('lName');
            $email = $this->input->post('email');
            $password = $this->input->post('confirm-password');
            $date = $this->input->post('bday');
            $gender = $this->input->post('gender');


            $pass = md5($password);

            $data = [
                'nm_depan' => $nama_depan,
                'nm_belakang' => $nama_belakang,
                'email' => $email,
                'password' => $pass,
                'tgl_lahir' => $date,
                'jns_kelamin' => $gender,
            ];

            $insert = $this->data_model->insert_user("user",$data);
            $this->session->set_userdata('masuk_user',TRUE);
        		$this->session->set_userdata('ses_idUser',$data['id']);
        		$this->session->set_userdata('ses_namaUser',$data['nm_depan']);
            redirect('user/jasa');

            
        }else{
        	$errors = $this->form_validation->error_array();
          $this->session->set_flashdata('errors_user',$errors);
          $this->session->set_flashdata('input', $this->input->post());

          redirect('user/signup');
        }

    }

	public function cek_email($email){
  		$this->load->model('data_model');
  		$this->form_validation->set_message('cek_email', 'Email sudah terdaftar');
  		if($this->data_model->cek_email($email)){
    		return true;
  		} else {
    		return false;
  		}
	}

public function jasa(){
	$this->load->model('data_model');
  $this->load->library('session');
  $data['product'] = $this->data_model->getAllProduct();
  $this->load->view('user/v_jasa',$data);
}

public function faq(){
      $this->load->library('session');
      $this->load->view('user/v_faq');
  }


  public function contact(){
      $this->load->library('session');
      $this->load->view('user/v_contact');
  }

  public function area(){
      $this->load->library('session');
      $this->load->view('user/v_cakupan_area');
  }



}