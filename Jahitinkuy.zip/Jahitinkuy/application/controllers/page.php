<?php
class Page extends CI_Controller{
  	function __construct(){
    	parent::__construct();
    	$this->load->helper(array('form', 'url'));
    	//cek jika user belum login
    	if($this->session->userdata('masuk') != TRUE){		
			$url=base_url();
			redirect($url);
		}
		$this->load->model('data_model');
	}

	public function index(){
		$this->load->library('session');
        $data['total_user'] = $this->data_model->jumlah_user();
        $data['total_pesanan'] = $this->data_model->total_pesanan();
        $data['total_invoice'] = $this->data_model->total_invoice();
        $data['total_jasa'] = $this->data_model->jumlah_jasa();
        $data['total_harga'] = $this->data_model->total_harga();
        $data['total_terjual'] = $this->data_model->total_terjual();
	    $this->load->view('admin/v_dashboard',$data);
  	}


  	function users(){
		$this->load->library('session');
		$data['total'] = $this->data_model->jumlah_user();
		$data['admin'] = $this->data_model->getAllAdmin();
		$data['user'] = $this->data_model->getAllUser();
	    $this->load->view('admin/v_users',$data);
  	}


  	function orders(){
		$this->load->library('session');
		$data['orders'] = $this->data_model->getAllPesanan();
        $data['total'] = $this->data_model->total_pesanan();
	    $this->load->view('admin/v_orders',$data);
  	}

    function invoice(){
        $this->load->library('session');
        $data['invoice'] = $this->data_model->getAllInvoice();
        $data['total'] = $this->data_model->total_invoice();
        $this->load->view('admin/v_invoice',$data);
    }

    function detail_invoice(){
        $this->load->library('session');
        $data['invoice'] = $this->data_model->getAllInvoice();
        $data['total'] = $this->data_model->total_invoice();
        $this->load->view('admin/v_detail_invoice',$data);
    }

  	function product(){
		$this->load->library('session');
		$data['total'] = $this->data_model->jumlah_jasa();
		$data['admin'] = $this->data_model->getAllAdmin();
		$data['product'] = $this->data_model->getAllProduct();
  		$this->load->view('admin/v_product',$data);
  	}

    public function insert_product(){
		//load session library to use flashdata
      	$this->load->library('session');

	 	//Check if file is not empty
     	if(!empty($_FILES['upload']['name'])){
        $config['upload_path'] = 'upload/';
            //restrict uploads to this mime types
        $config['allowed_types'] = 'jpg|jpeg|png';
        $config['file_name'] = $_FILES['upload']['name'];
        
            //Load upload library and initialize configuration
        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        
        if($this->upload->do_upload('upload')){
            $uploadData = $this->upload->data();
            $filename = $uploadData['file_name'];

			//set file data to insert to database
            $file['kode_jasa'] = $this->input->post('kode_jasa');
            $file['kategori'] = $this->input->post('kategori');
            $file['jenis'] = $this->input->post('jenis');
            $file['harga'] = $this->input->post('harga');
            $file['deskripsi'] = $this->input->post('deskripsi');
            $file['gambar_jasa'] = $filename;
            

            $query = $this->data_model->insertData($file);
				if($query){
					$this->session->set_flashdata('success','File uploaded successfully');
				   	redirect(site_url('page/product'));				  
			   }
			   else{
				   header('location:'.base_url().$this->index());
				   $this->session->set_flashdata('error','File uploaded but not inserted to database');
			   }

        }else{
          header('location:'.base_url().$this->index());
          $this->session->set_flashdata('error','Cannot upload file.'); 
        }
      }else{
        header('location:'.base_url().$this->index());
        $this->session->set_flashdata('error','Cannot upload empty file.');
      }
  	}

  	public function delete_product($id=null){
  		$this->load->library('session');
        	if (!isset($id)) show_404();
        
        	if ($this->data_model->delete_data($id)) {
			$this->session->set_flashdata('success','File deleted successfully');
            redirect(site_url('page/product'));
        }
  	}


  	public function update_jasa(){
		$this->load->library('session');

		if(!empty($_FILES['upload']['name'])){
        $config['upload_path'] = 'upload/';
        //restrict uploads to this mime types
        $config['allowed_types'] = 'jpg|jpeg|png';
        $config['file_name'] = $_FILES['upload']['name'];
        
        //Load upload library and initialize configuration
        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        
        if($this->upload->do_upload('upload')){
            $uploadData = $this->upload->data();
            $filename = $uploadData['file_name'];

			//set file data to insert to database
			$id = $this->input->post('id');
            $file['kode_jasa'] = $this->input->post('kode_jasa');
            $file['kategori'] = $this->input->post('kategori');
            $file['jenis'] = $this->input->post('jenis');
            $file['harga'] = $this->input->post('harga');
            $file['deskripsi'] = $this->input->post('deskripsi');
            $file['gambar_jasa'] = $filename;
		 
			$where = array(
				'id' => $id
			);

			$this->data_model->update_data($where,$file,'jasa');
			redirect('page/product');
			// if($berhasil){
			// 	$this->load->view('admin/v_product');
			// 	$this->session->set_flashdata('success','File update successfully');
			// }
			// else{
			// 	// header('location:'.base_url().$this->index());
			// 	// $this->session->set_flashdata('error','File update but not update to database');
			// 	echo "error";
			// }
		}
		}
	}


	function insert_user(){
		$this->load->library('form_validation');
        $this->form_validation->set_rules('fName', 'Nama','required|min_length[1]|max_length[30]');
		$this->form_validation->set_rules('email', 'Email','trim|required|min_length[1]|max_length[30]|valid_email|callback_cek_email');
        $this->form_validation->set_rules('password', 'Password','required|min_length[8]');
        $this->form_validation->set_rules('confirm-password', 'Konfirmasi Password', 'required|matches[password]');
		$this->form_validation->set_rules('bday', 'Tanggal lahir','trim|required');
        $this->form_validation->set_rules('gender', 'Jenis Kelamin','required');


        if($this->form_validation->run()==true){

            $nama_depan = $this->input->post('fName');
            $nama_belakang = $this->input->post('lName');
            $email = $this->input->post('email');
            $password = $this->input->post('confirm-password');
            $date = $this->input->post('bday');
            $gender = $this->input->post('gender');


            $pass = md5($password);

            $data = [
                'nm_depan' => $nama_depan,
                'nm_belakang' => $nama_belakang,
                'email' => $email,
                'password' => $pass,
                'tgl_lahir' => $date,
                'jns_kelamin' => $gender,
            ];

            $insert = $this->data_model->insert_user("user",$data);
            redirect('page');

            
        }else{
        	$errors = $this->form_validation->error_array();
            $this->session->set_flashdata('errors_user',$errors);
            $this->session->set_flashdata('input', $this->input->post());

            redirect('page');
        }

    }

    public function cek_email($email){
        $this->form_validation->set_message('cek_email', 'Email sudah terdaftar');
        if($this->data_model->cek_email($email)){
            return true;
        } else {
            return false;
        }
    }

    public function delete_user($id=null){
  		$this->load->library('session');
        	if (!isset($id)) show_404();
        
        	if ($this->data_model->delete_user($id)) {
            redirect(site_url('page/users'));
        }
  	}

  	function edit_user($id){
		$where = array('id' => $id);
		$data['user'] = $this->data_model->edit_user($where,'user')->result();
		$data['admin'] = $this->data_model->getAllAdmin();
		$this->load->view('admin/v_editUser',$data);
	}

	public function update_user(){
		$this->load->library('session');
		$this->load->library('form_validation');
        $this->form_validation->set_rules('fName', 'Nama','required|min_length[1]|max_length[30]');
		$this->form_validation->set_rules('email', 'Email','trim|required|min_length[1]|max_length[30]|valid_email');
        $this->form_validation->set_rules('password', 'Password','required|min_length[8]');
        $this->form_validation->set_rules('confirm-password', 'Konfirmasi Password', 'required|matches[password]');
		$this->form_validation->set_rules('bday', 'Tanggal lahir','trim|required');
        $this->form_validation->set_rules('gender', 'Jenis Kelamin','required');


        if($this->form_validation->run()==true){

        	$id = $this->input->post('id');
            $nama_depan = $this->input->post('fName');
            $nama_belakang = $this->input->post('lName');
            $email = $this->input->post('email');
            $password = $this->input->post('confirm-password');
            $date = $this->input->post('bday');
            $gender = $this->input->post('gender');


            $pass = md5($password);

            $data = array(
                'nm_depan' => $nama_depan,
                'nm_belakang' => $nama_belakang,
                'email' => $email,
                'password' => $pass,
                'tgl_lahir' => $date,
                'jns_kelamin' => $gender
            );

            $where = array(
				'id' => $id
			);

			$this->data_model->update_user($where,$data,'user');
			redirect('page/users');
		}else{
        	$errors = $this->form_validation->error_array();
            $this->session->set_flashdata('errors',$errors);
            $this->session->set_flashdata('input', $this->input->post());

            redirect('index.php/page/edit_user/'.$this->input->post('id'));
			// if($berhasil){
			// 	$this->load->view('admin/v_product');
			// 	$this->session->set_flashdata('success','File update successfully');
			// }
			// else{
			// 	// header('location:'.base_url().$this->index());
			// 	// $this->session->set_flashdata('error','File update but not update to database');
			// 	echo "error";
			// }
		}
		
	}

	public function insert_admin(){
		$this->load->library('form_validation');
        $this->form_validation->set_rules('nama', 'Nama','required');
		$this->form_validation->set_rules('email', 'Email','trim|required|min_length[1]|valid_email|callback_cek_email_admin');
        $this->form_validation->set_rules('password', 'Password','required|min_length[8]');
		$this->form_validation->set_rules('username', 'Username','trim|required');
        $this->form_validation->set_rules('level', 'Level','required');


        if($this->form_validation->run()==true){


	        $nama = $this->input->post('nama');
            $email = $this->input->post('email');
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $level = $this->input->post('level');


            $pass = md5($password);

            $data = [
                'nama' => $nama,
                'email' => $email,
                'password' => $pass,
                'username' => $username,
                'level' => $level
            ];

            $insert = $this->data_model->insert_admin("admin",$data);
            redirect('page');
            
        }else{
        	$errors = $this->form_validation->error_array();
            $this->session->set_flashdata('errors_admin',$errors);
            $this->session->set_flashdata('input', $this->input->post());

            redirect('page');
        }

    }


    public function cek_email_admin($email){
        $this->form_validation->set_message('cek_email_admin', 'Email sudah terdaftar');
        if($this->data_model->cek_email_admin($email)){
            return true;
        } else {
            return false;
        }
    }

    public function login_user(){
        $this->load->library('session');
        $this->load->view('user/v_login');
    }


}