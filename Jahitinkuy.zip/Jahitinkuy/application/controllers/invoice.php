<?php

	class Invoice extends CI_Controller{

		public function __construct(){
		parent::__construct();
			$this->load->model('invoice_model');
		}

		public function detail($id_invoice){
				$data['invoice'] = $this->invoice_model->ambil_id_invoice($id_invoice);
				$data['pesanan'] = $this->invoice_model->ambil_id_pesanan($id_invoice);
				$this->load->view('admin/v_detail_invoice', $data);
			}

		public function delete_order($id=null){
  		if($this->session->userdata('akses')=='1' || $this->session->userdata('akses')=='2'){
        	if (!isset($id)) show_404();
        
        	if ($this->invoice_model->delete_order($id)) {
            redirect(site_url('page/orders'));
        }
      }else{
      	echo "Anda tidak berhak menghapus";
      }
  	}
		
	}

?>