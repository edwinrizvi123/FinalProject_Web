<?php
	class Checkout extends CI_Controller{

		public function __construct(){
		parent::__construct();

			if($this->session->userdata('masuk_user') == false){
				$this->session->set_flashdata('msg', ' Anda belum login. Silahkan login terlebih dahulu');
				redirect('user/login');
			}
		}


		public function addToCart($id){
			$this->load->library('session');
			$this->load->model('data_model');
			$jasa = $this->data_model->find_jasa($id);

			$data = array(
	        'id'      => $jasa->id,
	        'qty'     => 1,
	        'price'   => $jasa->harga,
	        'name'    => $jasa->kategori,
	        'options' => $jasa->jenis,
	        'test'    => $jasa->gambar_jasa,
	        'kode'    => $jasa->kode_jasa,
	        
			);

			$this->cart->insert($data);
			redirect('user/jasa');

		}

		public function remove_cart($rowid){

			$data = array(
	      	'rowid'  => $rowid,
	      	'qty'    => 0,
			);

			$this->cart->update($data);
			redirect('checkout/checkout');
		}

		public function checkout(){
			$tgl=date('dmY');

				$total =  random_string('numeric', 4);
				$total2 =  random_string('numeric', 2);
				$total3 =  random_string('numeric', 1);

				$kode = "JK".$tgl.$total;
			$this->load->library('session');
			$this->load->model('data_model');
			$data['user'] = $this->data_model->getAllUser();
			$data['product'] = $this->data_model->getAllProduct();
			$data['kode'] = $kode;
			$this->load->view('user/v_checkout',$data);
		}


		public function pesan($id){
			$this->load->model('data_model');
			$this->load->library('session');
			$this->load->library('form_validation');
        	$this->form_validation->set_rules('fName', 'Nama','required|min_length[1]|max_length[30]');
        	$this->form_validation->set_rules('phone', 'Telepon','trim|numeric|required|min_length[10]');
        	$this->form_validation->set_rules('alamat', 'Alamat', 'required');
			$this->form_validation->set_rules('instruksi', 'Instruksi','required');


        	if($this->form_validation->run()==true){


	           		$this->data_model->pesan1();

	            	$where = array('id' => $id);
					$id_pes['idpes'] = $this->data_model->detail_pesanan($where,'invoice')->result();
					$id_pes['invoice'] = $this->data_model->getAllInvoice();
					$this->load->view('user/v_detail_pesanan',$id_pes);

            
        	}else{
	        	$errors = $this->form_validation->error_array();
	            $this->session->set_flashdata('errors_pesan',$errors);
	            $this->session->set_flashdata('input', $this->input->post());

	            redirect('checkout/checkout');
        	}

    	}

   //  	function detail_pesanan(){
   //  		$this->load->library('session');
   //  		$this->load->model('data_model');
   //  		$data['idpes'] = $this->data_model->detail_pesanan($where,'invoice')->result();
			// $data['invoice'] = $this->data_model->getAllInvoice();
			// $data['id_pesanan'] = $this->data_model->id_pesanan();
			// $this->load->view('user/v_detail_pesanan',$data);

   //  	}


    	public function hapus_cart(){
			$this->cart->destroy();
			redirect('user/jasa');
		}


		

}?>