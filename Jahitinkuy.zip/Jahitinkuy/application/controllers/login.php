<?php
class Login extends CI_Controller{

	function __construct(){
    parent::__construct();
    $this->load->model('login_model');
	}

	function index(){
		$this->load->view('admin/v_login');
	}

	function auth(){
    $username=htmlspecialchars($this->input->post('username',TRUE),ENT_QUOTES);
    $password=htmlspecialchars($this->input->post('password',TRUE),ENT_QUOTES);

    $cek_admin=$this->login_model->auth_admin($username,$password);

     if($cek_admin->num_rows() > 0){ //jika login sebagai dosen
				$data=$cek_admin->row_array();
        		$this->session->set_userdata('masuk',TRUE);
			        if($data['level']=='1'){ //Akses admin
			            $this->session->set_userdata('akses','1');
			            $this->session->set_userdata('ses_id',$data['id']);
			            $this->session->set_userdata('ses_nama',$data['nama']);
			            redirect('page');
		         	}else{ //akses dosen
		            $this->session->set_userdata('akses','2');
								$this->session->set_userdata('ses_id',$data['id']);
		            $this->session->set_userdata('ses_nama',$data['nama']);
		            redirect('page');
		         	}
        }else{ 
					// jika username dan password tidak ditemukan atau salah
						$url=base_url();
						$this->session->set_flashdata('msg',' Check your username or password');
						redirect($url);	
        }
  	}

  	function logout(){
        $this->session->sess_destroy();

        redirect('page');
        $this->session->set_flashdata('keluar',' Anda berhasil keluar dari cobaan');
        
    }

    function login_user(){
        $email=htmlspecialchars($this->input->post('email',TRUE),ENT_QUOTES);
    	$password=htmlspecialchars($this->input->post('password',TRUE),ENT_QUOTES);

    	$cek_user=$this->login_model->auth_user($email,$password);

    	if($cek_user->num_rows() > 0){
			$data=$cek_user->row_array();
        	$this->session->set_userdata('masuk_user',TRUE);
        	$this->session->set_userdata('ses_idUser',$data['id']);
        	$this->session->set_userdata('ses_uname_dp',$data['nm_depan']);
            $this->session->set_userdata('ses_uname_bl',$data['nm_belakang']);
            $this->session->set_userdata('ses_email',$data['email']);
        	redirect('user/jasa');
		}else{
			$this->session->set_flashdata('msg',' Check your username or password');
			redirect('user/login');	
        }	
    }

    function logout_user(){
        $this->session->sess_destroy();

        redirect('user/login');
        $this->session->set_flashdata('keluar',' Anda berhasil keluar dari cobaan');
        
    }

    






}