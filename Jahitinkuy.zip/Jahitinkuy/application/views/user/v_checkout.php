<!DOCTYPE html>
<html>
<head>
	<title>Checkout | Jahitinkuy</title>
	<!-- Load Head -->
	<?php $this->load->view('user/partials/v_head.php') ?>
	<style>
		.container-checkout{
			margin: 10px 10px 50px 10px;
		}

		.form-checkout{
			margin: 0 15px;
			font-family: 'Oswald', sans-serif;
			height: 700px;
		}

		hr{
			margin: 10px 0 30px;
			height: 3px;
			background: #FF046E;
		}

		label{
			font-size: 16px;
			font-weight: normal;
		}

		.form-textarea{
			height: 100px !important;
		}

		.form-control{
			font-weight: 100;
			font-size: 14px;
			font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
		}

		.form-control:focus{
			border: 1px solid #717171;
			box-shadow: none;
		}

		.btn{
			background: #FF046E;
			margin: 30px 15px 0 15px;
			color: white;
			transition: ease background 0.3s;
		}

		.btn:hover{
			background: #D60045;
			color: white;
		}

		.badge{
			background: #FF046E;
			color: white;
			font-weight: lighter;
			padding: 5px;
			width: 70px;
			float: left !important;
			margin: 0 25px 0 25px;
		}

		.list-cart{
			padding: 0 !important;
			overflow: hidden;
			margin-bottom: 5px;
			background: #FFFFEF;
			border: 1px solid #F1DD2D;
		}

		.list-cart-desc{
			margin-top: 25px;
			font-size: 16px;
		}


		.img-preview{
			height: 70px;
			width: 70px;
			margin: 0 !important;
			float: left !important;
		}

		.list-subtotal{
			width: 115px;
			height: 70px;
			float: right;
			background: #FCFCC3;
			border-left: 2px dashed #333333;
			padding: 10px;
		}

		.remove-cart{
			color: #333333;
			float: right;
		}

		.list-group-cart{
			overflow: auto;
			max-height: 230px;
			vertical-align: middle;
		}

		.ket{
			padding: 20px;
			background: #FF046E;
			color: white;
			text-align: justify;
			font-size: 16px;
			border-radius: 5px;
			font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;;
		}

		.harga{
			padding: 0;
			height: 50px;
			border-bottom: 3px solid #333333;
			background: #FFFFEF;
		}

		.total{
			padding: 3px;
			height: 50px;
			background: #FCFCC3;
		}

		.total-harga{
			float: right;
		}

		.btn-pesan{
			float: right;
		}



	</style>
</head>
<body>
	<!-- Load Navbar -->
	<?php $this->load->view('user/partials/v_navbar.php') ?>
	<!-- Load Floating -->
	<?php $this->load->view('user/partials/v_floating.php') ?>

	<?php $id_kode = $kode ?>

	<section>
		<div class="col-12 container-checkout row">
			<form action="<?php echo base_url().'index.php/checkout/pesan/'.$id_kode ?>" method="post">
				<div class="col-md-6" style="border-right: 2px dashed #333333">
					<div class="form-checkout">
						<h2>Detail</h2>
						<hr>
						<div class="row">
							<div class="form-group col-md-6">
								<label for="fname">Nama Depan</label>
								<input type="hidden" name="id" value="<?php echo $id_kode ?>">
								<input class=" input-lg form-control" type="text" id="fname" name="fName" required="required" value="<?php echo $this->session->userdata('ses_uname_dp'); ?>">
							</div>
							<div class="form-group col-md-6">
								<label for="lname">Nama Belakang</label>
								<input class="form-control input-lg" type="text" id="lname" name="lName" required="required" value="<?php echo $this->session->userdata('ses_uname_bl'); ?>">
							</div>
						</div>
						<div class="row">
							<div class="form-group col-md-6">
								<label for="email">Email</label>
								<input class="form-control input-lg" type="email" name="email" disabled="disabled" required="email" value="<?php echo $this->session->userdata('ses_email'); ?>">
							</div>
							<div class="form-group col-md-6">
								<label for="phone">No Telepon</label>
								<input class="form-control input-lg" type="number" name="phone" required="number">
							</div>
						</div>
						<div class="form-group">
							<label for="alamat">Alamat</label>
							<textarea class="form-control form-textarea" name="alamat" id="alamat"></textarea>
						</div>
						<div class="form-group">
							<label for="area">Area</label>
							<select class="form-control input-lg" id="area" name="area">
								<optgroup label="~Yogyakarta"></optgroup>
									<option>Kota Gede</option>
									<option>Umbulharjo</option>
								<optgroup label="~Sleman"></optgroup>
									<option>Berbah</option>
									<option>Kalasan</option>
									<option>Depok</option>
								<optgroup label="~Bantul"></optgroup>
									<option>Banguntapan</option>
									<option>Pleret</option>
									<option>Imogiri</option>
									<option>Sewon</option>
									<option>Bantul</option>
							</select>
						</div>
						<div class="form-group">
							<label for="catatan">Catatan</label>
							<textarea class="form-control form-textarea" name="catatan" id="catatan"></textarea>
						</div>
					</div>
					<button class="btn" type="button"><i class="mdi mdi-backburger"></i> Kembali</button>
				</div>
				<div class="col-md-6">
					<div class="form-checkout">
						<h2>Jasa</h2>
						<hr>
						<p style="font-size: 16px">List Keranjang</p>
						<ul class="list-group list-group-cart" id="list-group">

							<?php if ($this->cart->total() == 0) { ?>
								<li class="list-group-item alert alert-warning text-justify">
									
						       			<h5><span class="mdi mdi-alert-warning"></span>Belum ada jasa yang dipilih.</h5>
						    		
								</li>
							<?php }else{ ?>
								<?php foreach ($this->cart->contents() as $items) { ?>
						  		<li class="list-group-item list-cart">
						  			<img class="img-preview" src="<?php echo base_url().'upload/'.$items['test']; ?>">
						  			<div class="row list-cart-desc col-md-8">
						  				<span class="badge"><?php echo $items['options']; ?></span>
						  				<?php echo $items['qty'] ?>x  <?php echo $items['name'] ?>
						  				<a class="remove-cart" href="<?php echo base_url().'index.php/checkout/remove_cart/'.$items['rowid']; ?>"><span class="mdi mdi-delete-empty"></span></a>
						  			</div>
						  			<div class="list-subtotal">
						  				<p>Subtotal</p>
						  				<b>Rp. <?php echo number_format($items['subtotal'], 0,',','.')  ?></b>
						  			</div>
						  		</li>
						  	<?php } ?>
						  	<?php } ?>

						</ul>
						<p class="ket">Jelaskan secara detail kepada kurir kami mau seperti apa yang ingin anda ubah agar tidak terjadi kesalahan saat pengerjaan.</p>
						<div class="form-group">
							<label for="instruksi">Instruksi</label>
							<textarea class="form-control form-textarea" name="instruksi" id="instruksi"></textarea>
						</div>
						<ul class="list-group">
						  	<li class="list-group-item harga">
						  			<h3 style="margin-top: 10px;">Harga</h3>
						  	</li>
						  	<li class="list-group-item total">
						  			<h3 style="margin: 0;">Total
						  			<span class="total-harga">Rp. <?php echo number_format($this->cart->total(), 0,',','.') ?></span></h3>
						  	</li>
	
						</ul>
					</div>
					<?php if ($this->cart->total() > 0) { ?>
					<button class="btn btn-pesan" type="submit"><i class="mdi mdi-credit-card-check-outline"></i> Pesan</button>
					<?php }else{

					} ?>
				</div>
			</form>
		</div>
	</section>

	<!-- Load Footer -->
	<?php $this->load->view('user/partials/v_footer.php') ?>

	<?php
    $errors = $this->session->flashdata('errors_pesan');
    if(!empty($errors)){ ?>
      	<div class="modal fade " id="myModal" role="dialog">
	    	<div class="modal-dialog ">
	    
		      	<!-- Modal content-->
		      	<div class="modal-content alert alert-warning">
		        	<div class="modal-header">
		          		<button type="button" class="close" data-dismiss="modal">&times;</button>
		          		<h4 class="modal-title">Whoops!</h4>
		        	</div>
		        	<div class="modal-body">
		          		<ul>
			          		<?php foreach ($errors as $error) : ?>
			          		<li><?= ($error) ?></li>
			          		<?php endforeach ?>
			      		</ul>
		        	</div>
		        	<div class="modal-footer">
		          		<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		        	</div>
		      	</div>
	      
	    	</div>
	  	</div>
	  	<script>
			$('#myModal').modal('show');
		</script>
	<?php }?>
</body>
</html>