<!DOCTYPE html>
<html>
<head>
	<title>Home | Jahitinkuy</title>
	<!-- Load Head -->
	<?php $this->load->view('user/partials/v_head.php') ?>
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">

	
	<style>
		@font-face {
       	 	font-family: heading-p;
        	src: url(<?php echo base_url('assets/fonts/Parisienne.ttf');  ?>);
		}

		@font-face {
       	 	font-family: heading-h1;
        	src: url(<?php echo base_url('assets/fonts/YuseiMagic-Regular.ttf');  ?>);
		}
		.banner-home{
			background: url(<?php echo base_url('assets/img/banner2.png');  ?>);
			background-size: cover;
			background-repeat: no-repeat;
			padding: 60px;
		}

		.heading-text{
			width: 60%;
			color: white;
			font-family: 'heading-h1';
			font-size: 50px;
		}

		.heading-text > p {
			font-family: 'heading-p';
			font-size: 24px;
			font-weight: bold;
		}

		.heading-text >  i{
			font-family: 'Great Vibes', cursive;
			font-size: 24px;
		}

		.btn-pesan-sekarang{
			border: 2px solid #FF046E;
			color: #FF046E;
			transition: ease 0.3s;
			font-size: 18px;
		}

		.btn-pesan-sekarang:hover{
			background: #FF046E;
			color: white;
		}


		.container-section{
			width: 80%;
			margin: 30px;

		}

		.container-cara-kerja{
			font-family: 'Oswald', sans-serif;

		}

		.container-cara-kerja > h2 {
			font-family: 'Oswald', sans-serif;
			position: relative;
		}

		.container-cara-kerja > b{
			height: 2px;
			background-color: black;
			display: block;
			flex: 1;
		}

		hr{
			width: 200px;
			height: 2px;
			background: #555;
		}

		.cara-kerja{
			padding: 15px 0px;
			height: 235px;
		}

		.border-right{
			border-right:1px solid #555;
		}

		.cara-kerja-item{
			text-align: center;
			color: #555;
			height: 100%;
		}

		.cara-kerja-item > p{
			color: #777;
		}

		.cara-kerja-img{
			width: 90px;
			height: 93px;
			margin-bottom: 10px;
		}

		.heading-harga{
			height: 50px;
			background: rgba(0,0,0,0.05);
			padding: 5px;
		}

		.harga-mulai{
			color: #555;
		}

		.harga-mulai-item{
			padding: 0;
			border:1px solid rgba(0,0,0,0.1);
			transition: ease 0.3s;
		}

		.harga-mulai-item:hover{
			box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
		}

		.isi-harga{
			padding: 10px 15px;
		}

		.desc{
			color:#777;
			margin-top: 30px;
		}

		.list-group-item:hover{
			background: #F5F5F5;
			cursor: default;
		}

		.btn-harga-selengkapnya{
			border: 2px solid #FF046E;
			color: #FF046E;
			transition: ease 0.3s;
			font-size: 20px;
			margin-top: 30px;
		}

		.btn-harga-selengkapnya:hover{
			background: #FF046E;
			color: white;
		}

	</style>
</head>
<body>
	<!-- Load Navbar -->
	<?php $this->load->view('user/partials/v_navbar.php') ?>
	<!-- Load Floating -->
	<?php $this->load->view('user/partials/v_floating.php') ?>

	<div class="container-banner">
		<div class="banner banner-home">
			<center>
				<div class="heading-text">
					<p>Solusi Jahit dan Permak Online</p>
					TIDAK <span style="color: #FF046E;">PERLU</span> RIBET<br>
					HANYA PERLU SATU SENTUHAN
					<i>Jaminan Kualitas dan Pelayanan</i><br>
					<a class="btn btn-pesan-sekarang" href="<?php echo base_url().'index.php/user/jasa' ?>">
						PESAN SEKARANG
					</a>
				</div>
				
			</center>
		</div>
	</div>
	<section>
		<center>
		<div class="container-section">
			<div class="container-cara-kerja">
				<h2>CARA KERJA</h2>
				<hr>
				<div class="cara-kerja row">
					<div class="cara-kerja-item col-md-3 border-right">
						<img class="cara-kerja-img" src="<?php echo base_url().'assets/img/pesan.png' ?>">
						<h4>ORDER</h4>
						<p>Pilih layanan serta jenis pakaian yang ingin dibantu oleh Jahitinkuy dan selesaikan pembayaran secara online</p>
					</div>
					<div class="cara-kerja-item col-md-3 border-right">
						<img class="cara-kerja-img" src="<?php echo base_url().'assets/img/jemput.png' ?>">
						<h4>PICKUP</h4>
						<p>Jahitinkuy akan menjemput pakaian sesuai waktu penjemputan ke lokasi anda yang telah didaftarkan</p>
					</div>
					<div class="cara-kerja-item col-md-3 border-right">
						<img class="cara-kerja-img" src="<?php echo base_url().'assets/img/proses.png' ?>">
						<h4>PROSES</h4>
						<p>Pakaian anda akan diproses dan diselesaikan oleh Jahitinkuy dalam 2 x 24 Jam</p>
					</div>
					<div class="cara-kerja-item col-md-3">
						<img class="cara-kerja-img" src="<?php echo base_url().'assets/img/delivery.png' ?>">
						<h4>DELIVERY</h4>
						<p>Jahitinkuy akan menghubungi anda untuk mengantarkan pakaian yang telah selesai diproses.</p>
					</div>
				</div>
			</div>

			<div class="container-cara-kerja" style="margin-top: 50px;">
				<h2>DAFTAR HARGA</h2>
				<hr>
				<div class="harga-mulai row">
					<div class="harga-mulai-item col-md-3">
						<div class="heading-harga">
							<h4>PERMAK</h4>
						</div>
						<div class="isi-harga">
							<div class="harga">
								<h1>Start From IDR 35,000</h1>
							</div>
							<div class="desc">
								<p>Mengubah ukuran pakaian</p>
								<ul class="list-group">
									<li class="list-group-item">Kemeja Batik</li>
									<li class="list-group-item">Celana Panjang & Pendek</li>
									<li class="list-group-item">Kaos</li>
									<li class="list-group-item">Seragam</li>
									<li class="list-group-item">Dress</li>
									<li class="list-group-item">dll</li>
								</ul>
							</div>
						</div>
					</div>
					
					<div class="harga-mulai-item col-md-3">
						<div class="heading-harga">
							<h4>Resleting</h4>
						</div>
						<div class="isi-harga">
							<div class="harga">
								<h1>Start From IDR 10,000</h1>
							</div>
							<div class="desc">
								<p>Mengganti Resleting</p>
								<ul class="list-group">
									<li class="list-group-item">Resleting Dress</li>
									<li class="list-group-item">Resleting Kain</li>
									<li class="list-group-item">Resleting Jaket</li>
									<li class="list-group-item">Resleting Denim/li>
									<li class="list-group-item">Resleting Blouse</li>
									<li class="list-group-item">dll</li>
								</ul>
							</div>
						</div>
					</div>

					<div class="harga-mulai-item col-md-3">
						<div class="heading-harga">
							<h4>JAHIT</h4>
						</div>
						<div class="isi-harga">
							<div class="harga">
								<h1>Start From IDR 95,000</h1>
							</div>
							<div class="desc">
								<p>Menjahit pakaian sesuai referensi Model</p>
								<ul class="list-group">
									<li class="list-group-item">Jahit Kebaya</li>
									<li class="list-group-item">Jahit Seragam</li>
									<li class="list-group-item">Jahit Gamis</li>
									<li class="list-group-item">Jahit Dress</li>
									<li class="list-group-item">Jahit Masker</li>
									<li class="list-group-item">dll</li>
								</ul>
							</div>
						</div>
					</div>

					<div class="harga-mulai-item col-md-3">
						<div class="heading-harga">
							<h4>POTONG</h4>
						</div>
						<div class="isi-harga">
							<div class="harga">
								<h1>Start From IDR 28,000</h1>
							</div>
							<div class="desc">
								<p>Memotong desain pakaian</p>
								<ul class="list-group">
									<li class="list-group-item">Kemeja Batik</li>
									<li class="list-group-item">Celana Panjang & Pendek</li>
									<li class="list-group-item">Kebaya</li>
									<li class="list-group-item">Seragam</li>
									<li class="list-group-item">Masker</li>
									<li class="list-group-item">dll</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<a class="btn btn-harga-selengkapnya" href="<?php echo base_url().'index.php/user/jasa' ?>">
					HARGA SELENGKAPNYA
				</a>
				<hr>
			</div>
		</div>
		</center>
	</section>



	<!-- Load Footer -->
	<?php $this->load->view('user/partials/v_footer.php') ?>
</body>
</html>