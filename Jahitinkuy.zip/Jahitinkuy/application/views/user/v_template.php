<!DOCTYPE html>
<html>
<head>
	<title>Checkout | Jahitinkuy</title>
	<!-- Load Head -->
	<?php $this->load->view('user/partials/v_head.php') ?>
</head>
<body>
	<!-- Load Navbar -->
	<?php $this->load->view('user/partials/v_navbar.php') ?>
	<!-- Load Floating -->
	<?php $this->load->view('user/partials/v_floating.php') ?>



	<!-- Load Footer -->
	<?php $this->load->view('user/partials/v_footer.php') ?>
</body>
</html>