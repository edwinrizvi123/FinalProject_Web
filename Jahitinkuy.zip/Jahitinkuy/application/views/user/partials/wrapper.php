<?php
//Struktur html
require_once('head.php');
require_once('navbar.php');
require_once('section.php');
require_once('footer.php');
?>
