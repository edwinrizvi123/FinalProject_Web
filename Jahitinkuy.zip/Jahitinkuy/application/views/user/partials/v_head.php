
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo base_url().'assets/mdi/css/materialdesignicons.min.css' ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/user/css/bootstrap.min.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/user/css/custom.css'); ?>">
  <link rel="stylesheet" href="<?php echo base_url('assets/user/css/bootstrap-datepicker.min.css'); ?>">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Oswald" rel="stylesheet">
  <link href="<?php echo base_url('assets/user/css/nucleo-icons.css'); ?>" rel="stylesheet" />
  <script src="<?php echo base_url('assets/js/jquery-3.5.1.js'); ?>"></script>
  <script src="<?php echo base_url('assets/user/js/bootstrap.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/user/js/bootstrap-datepicker.min.js'); ?>"></script>
  <script src="<?php echo base_url('assets/user/locales/bootstrap-datepicker.id.min.js'); ?>"></script>
  <link rel="shortcut icon" href="<?php echo base_url().'assets/img/favicon3.png' ?>" />

  