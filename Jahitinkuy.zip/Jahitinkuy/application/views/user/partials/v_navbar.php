<nav class="navbar navbar-inverse nav-custom" style="margin-bottom: 0; background: #1E1E2F">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">
        <img class="logo-navbar" src="<?php echo base_url('assets/img/logo.png'); ?>">
      </a>
    </div>
    <ul class="nav navbar-nav nav-menu-custom">
      <li><a href="<?php echo base_url('index.php/home'); ?>">Home</a></li>
      <li><a href="<?php echo base_url('index.php/faq'); ?>">FAQ</a>
      </li>
      <li><a href="<?php echo base_url('index.php/contact'); ?>">Contact</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right nav-menu-custom">
      <?php if($this->session->userdata('masuk_user')) { ?>
        <li><a href="<?php echo base_url('index.php/checkout'); ?>" style="color: white"><span class="mdi mdi-cart-variant"></span>
          Rp. <?php echo number_format($this->cart->total(), 0,',','.'); ?></a>
        </li>

        <li><a href=""><span class="mdi mdi-account-outline"></span> Hallo <?php echo $this->session->userdata('ses_uname_dp') ?></a></li>

        <li><a href="<?php echo base_url('index.php/login/logout_user'); ?>"><span class="mdi mdi-logout"></span> logout</a></li>
      <?php }else{ ?>
        <li><a href="<?php echo base_url('index.php/signup'); ?>"><span class="mdi mdi-account-multiple-plus-outline"></span> Sign Up</a></li>
        <li><a href="<?php echo base_url('index.php/login'); ?>"><span class="mdi mdi-login"></span> Login</a></li>
      <?php } ?>
    </ul>
  </div>
</nav>