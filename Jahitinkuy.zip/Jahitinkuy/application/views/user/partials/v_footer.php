		<div class="footer-custom" style="background: #1E1E2F">
			<center>
			<div class="container-fluid">
				<a href=""><h3>Jahitinkuy</h3></a>
			</div>
			<div class="sosmed-footer-custom">
				<p>Copyright 2020 © Jahitinkuy Digital Indonesia</p>
			</div>
			</center>
		</div>