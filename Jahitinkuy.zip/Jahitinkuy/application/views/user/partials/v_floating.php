<a href="#" class="floating-btn" style="z-index: 99999;">
  <img title="Hubungi kami via Whatsapp" class="floating-btn-wa" src="<?php echo base_url('assets/img/floating_wa.png'); ?>">
</a>
