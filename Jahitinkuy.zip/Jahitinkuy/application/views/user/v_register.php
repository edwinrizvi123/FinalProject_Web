<!DOCTYPE html>
<html>
<head>
	<title>Signup | Jahitinkuy</title>
	<!-- Load Head -->
	<?php $this->load->view('user/partials/v_head.php') ?>
	<style>
		.container-login-custom,.container-form-login,.container-banner-login,.banner-login{
			height: 630px;
		}

		.button-login{
			background: #FF046E; 
			width: 50%;
			margin-top: 20px;
			color: white;
			transition: ease 0.3s;
		}

		.button-login:hover{
			background: #D60045;
			color: white;
		}
	</style>
</head>
<body style="background: url(<?php echo base_url('assets/img/bg_pattern1.jpg'); ?>);">
<!-- Load Navbar -->
<?php $this->load->view('user/partials/v_navbar.php') ?>
<center>
<?php $this->load->view('user/partials/v_floating.php') ?>

	<?php if($this->session->flashdata('msg')){ ?>
    <div class="alert alert-warning text-center" style="margin-top:20px;">
       <span class="mdi mdi-alert-circle-outline"></span><?php echo $this->session->flashdata('msg'); ?>
    </div><?php } ?>

<div class="container-login-custom" style="margin-top: 50px;">
	<div class="col-md-6 container-form-login">
		<div>
			<h3>Daftar</h3>
				<form action="<?php echo base_url ('index.php/user/register') ?>" method="post">
					<div class="form-group row">
					  	<div class="col-md-6">
					    	<label for="nama-depan">Nama depan</label>
					    	<input name="fName" type="text" class="form-control" id="nama-depan">
					  	</div>
					  	<div class="col-md-6">
					    	<label for="nama-belakang">Nama belakang</label>
					    	<input name="lName" type="text" class="form-control" id="nama-belakang">
					  	</div>
					</div>
				  	<div class="form-group">
				    	<label for="email">Email</label>
				    	<input name="email" type="email" class="form-control" id="email">
				  	</div>
				  	<div class="form-group row">
					  	<div class="col-md-6">
					    	<label for="bday">Tanggal lahir</label>
					    	<input name="bday" type="text" class="form-control" id="bday" placeholder="yyyy-mm-dd">
					  	</div>
					  	<div class="col-md-6">
					    	<label for="jk">Jenis kelamin</label>
					    	<select name="gender" class="form-control" id="jk">
					    		<option></option>
						    	<option>Laki-laki</option>
						    	<option>Perempuan</option>
						  	</select>
					  	</div>
					</div>
				  	<div class="form-group">
				    	<label for="password">Password</label>
				    	<input name="password" type="password" class="form-control" id="password">
				  	</div>
				  	<div class="form-group">
				    	<label for="confirm-password">Re-type Password</label>
				    	<input name="confirm-password" type="password" class="form-control" id="confirm-password">
				  	</div>
				  	<center>
				  	<button type="submit" class="btn btn-lg btn-default button-login">Daftar</button>
				  	</center>
				</form>
		</div>
	</div>
	<div class="col-md-6 container-banner-login">
		<img class="banner-login" src="<?php echo base_url('assets/img/banner_login_gopay.png'); ?>">
	</div>
</div>

</center>
<?php $this->load->view('user/partials/v_footer.php') ?>
<?php
    $errors = $this->session->flashdata('errors_user');
    if(!empty($errors)){ ?>
      	<div class="modal fade" id="myModal" role="dialog">
	    	<div class="modal-dialog ">
	    
		      	<!-- Modal content-->
		      	<div class="modal-content alert alert-danger">
		        	<div class="modal-header">
		          		<button type="button" class="close" data-dismiss="modal">&times;</button>
		          		<h4 class="modal-title">Whoops!</h4>
		        	</div>
		        	<div class="modal-body">
		          		<ul>
			          		<?php foreach ($errors as $error) : ?>
			          		<li><?= ($error) ?></li>
			          		<?php endforeach ?>
			      		</ul>
		        	</div>
		        	<div class="modal-footer">
		          		<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		        	</div>
		      	</div>
	      
	    	</div>
	  	</div>
	  	<script>
			$('#myModal').modal('show');
		</script>
	<?php }?>
	<script>
	  $( function() {
	    $( "#bday" ).datepicker({
	      autoclose:true,
	      todayHighlight:true,
	      format:'yyyy-mm-dd',
	      language: 'id'
	    });
	  } );
  </script>
</body>
</html>

        