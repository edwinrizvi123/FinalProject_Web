<!DOCTYPE html>
<html>
<head>
	<title>Detail Pesanan | Jahitinkuy</title>
	<!-- Load Head -->
	<?php $this->load->view('user/partials/v_head.php') ?>
	<style>
		.container-detail-pesanan{
			margin: 10px 150px 50px 150px;
			font-family: 'Oswald', sans-serif;
		}

		.container-detail-pesanan > h1{
			text-align: center;
			
		}

		.circle{
			border: 10px solid #FF046E;
			border-radius: 100%;
			height: 200px;
			width: 200px;
			padding: 25px 10px;
			margin-top: 50px;
		}

		.alert{
			margin-top: 50px;
		}

		.bayar{
			background: #FF046E;
			margin-top: 30px;
			color: white;
			transition: ease background 0.3s;
			font-size: 18px;
			padding: 10px;
		}

		.bayar:hover{
			background: #D60045;
			color: white;
		}

		.item1 { grid-area: cart; }
		.item2 { grid-area: total; }
		.item3 { grid-area: alamat; }

		.grid-container {
		  display: grid;
		  grid-template-areas:
		    'cart alamat'
		    'total alamat';
		  grid-gap: 10px;
		  margin-top: 0;
		  padding: 0px;
		}

		.grid-container > div {
		  background-color: #EEEEEE;
		  padding: 20px 20px;
		  border-radius: 5px;
		  text-align: left;
		}

		.subtotal{
			text-align: right;
		}

		.detail{
			width: 100%;
			background: #EEEEEE;
			border-radius: 5px;
			padding: 10px;
		}

		.container-detail{


		}

		.badge{
			background: #FF046E;
			color: white;
			font-weight: lighter;
			padding: 5px;
			width: 70px;
			float: right;
			margin: 0;
		}

		td{
			padding: 20px 20px;
		}

		th{
			padding: 20px 20px;
		}

		.total{
			margin-top: 20px;
		}

		.alamat{
			padding: 20px;
			background: #EEEEEE;
			border-radius: 5px;
		}

		.alamat > h4 {
			color: #FF046E;
			margin-top: 20px !important;
			text-decoration: underline;
		}

		.alamat > p {
			
			font-weight: lighter;
		}

		.metode-pembayaran{
			margin: 5px 0;
			padding: 10px;
			vertical-align: middle;
			transition: ease background 0.3s;
		}

		.metode-pembayaran:hover{
			background: #F5F5F5;
		}

		.modal-bayar{
			width: 400px;
		}

		.img-metode-pembayaran{
			height: 50px;
			width: 50px;
			float: left;
		}

		.img{
			height: 50px;
			width: 100px;
			justify-content: center;
		}

		.ket-bayar{
			padding: 0;
			font-size: 17px;
			font-weight: bold;
			margin-left: 10px;

		}

		.ket-bayar > p{
			font-size: 12px;
			font-weight: lighter;
		}

		.list-group > a{
			color: #333333;
			width: 100%;
			padding: 0px;
			border: none;
			cursor: pointer;
		}


		.modal-body{
			background: #EEEEEE;
		}

		.panah{
			color: #FF046E;
			font-size: 24px;
			margin-left: 10px;
		}

		.modal-footer{
			border-bottom-left-radius: 5px;
			border-bottom-right-radius: 5px;
			border-top: 2px dashed black;
		}

		.circle-pembayaran{
			border: 10px solid #BCBCBC;
			border-radius: 100%;
			height: 150px;
			width: 150px;
			padding: 15px 26px;
			justify-content: center;
			vertical-align: middle;
			margin-bottom: 25px;
		}

		.container-rek{
			background: white;
			border-radius: 5px;
			padding: 25px 20px;
		}

		.img-bayar{
			margin-top: 15px;
			width: 75px;
			height: 75px;
		}


	</style>
</head>
<body>
	<!-- Load Navbar -->
	<?php $this->load->view('user/partials/v_navbar.php') ?>
	<!-- Load Floating -->
	<?php $this->load->view('user/partials/v_floating.php') ?>

	<section>
		<div class="col-12 container-detail-pesanan">
			<?php foreach ($idpes as $i) { ?>


			<h1>Id Pesanan : <?php echo $i->id; ?></h1>
			
			<center>
				<div class="circle">
					<h1>Pesanan Baru</h1>
				</div>
				<?php 
				$tambah = 1;
				$tgl = $i->tanggal; 
				$batas = format_indo(date('Y-m-d H:i:s', strtotime($tgl.' + '.$tambah.' Days')));
				?>
	    		<div class="alert alert-success text-center">
	       			<h4><span class="mdi mdi-check-circle-outline"></span> Pesanan anda berhasil dibuat. Silahkan melakukan pembayaran sebelum <u><?php echo $batas; ?></u> agar pesanan anda segera kami proses. </h4>
	    		</div>
	    	</center>
	    		<div class="row container-detail col-12">
	    			<div class="col-md-6 text-left">
	    				<h4>Detail Pesanan</h4>
				  					
				  			<table class="detail">
				  				<?php foreach ($this->cart->contents() as $items) { ?>
				  				<tr >
				  					<td><?php echo $items['qty'] ?>x</td>
				  					<td><?php echo $items['name'] ?></td>
				  					<td style="text-align: right;"><span class="badge"><?php echo $items['options']; ?></span></td>
				  					<td class="subtotal">Rp. <?php echo number_format($items['subtotal'], 0,',','.')  ?></td>
				  				</tr>
				  				<?php } ?>
				  			</table>

				  			<table class="detail total">
				  				<tr>
				  					<th><h3>Total</h3></th>
				  					<th style="text-align: right;"><h3>Rp. <?php echo number_format($this->cart->total(), 0,',','.') ?></h3></th>
				  				</tr>
				  			</table>
	    			</div>
	    			<div class="col-md-6 text-left" style="padding-left: 2px;">
	    				<h4>Alamat</h4>
	    				<div class="alamat">
	    					<h4 style="margin-top: 0">Alamat</h4>
	    					<p><?php echo $i->alamat; ?></p>
	    					<h4>Area</h4>
	    					<p><?php echo $i->area; ?></p>
	    					<h4>Telepon</h4>
	    					<p><?php echo $i->telepon; ?></p>
	    					<h4>Catatan</h4>
	    					<p><?php echo $i->catatan; ?></p>
	    				</div>
	    			</div>
	    		</div>
	    		<center>
	    		<a class="btn bayar" data-toggle="modal" data-target="#modalBayar">Bayar Sekarang</a>
	    		<a href="<?php echo base_url().'index.php/checkout/hapus_cart' ?>" class="btn bayar">Selesai</a>
	    		</center>
			
		
		</div>
	</section>
	<div class="modal fade" id="modalBayar" role="dialog">
	  <div class="modal-dialog modal-bayar">
	   <!-- Modal content-->
	   <div class="modal-content">
	    <div class="modal-header">
	     <button type="button" class="close" data-dismiss="modal">&times;</button>
	     <h4 class="modal-title"><button type="button" id="btn-previous" class="close" style="float: left;"><span class="mdi mdi-chevron-left" style="font-size: 30px;"></span></button>Pilih Metode Pembayaran</h4>
	    </div>
	    <div class="modal-body">
	    	<div id="home">
	    	<ul class="list-group">
	       <a id="idtf">
	       	<li class="list-group-item metode-pembayaran row">
	       			<img class="img-metode-pembayaran" src="<?php echo base_url().'assets/img/atm.png'?>">
	       			<div class="col-md-8 ket-bayar">
	       				Transfer
	       				<p>Bayar dari ATM Mandiri, BRI, Jenius</p>
	       			</div>
	       			<span class="mdi mdi-arrow-right-bold-circle-outline panah"></span>
	       		
	       </li>
	       </button>
	      <a id="idovo">
	      	<li class="list-group-item metode-pembayaran row">
	       		<img class="img-metode-pembayaran" src="<?php echo base_url().'assets/img/ovo.png'?>">
	       		<div class="col-md-8 ket-bayar">
	       			OVO
	       			<p>Bayar menggunakan OVO</p>
	       		</div>
	       		<span class="mdi mdi-arrow-right-bold-circle-outline panah"></span>
	      	</li>
	      </a>
	      <a id="idgopay">
	      	<li class="list-group-item metode-pembayaran row">
	       			<img class="img-metode-pembayaran" src="<?php echo base_url().'assets/img/gopay.png'?>">
	       			<div class="col-md-8 ket-bayar">
	       				GOPAY
	       				<p>Bayar menggunakan GOPAY</p>
	       			</div>
	       			<span class="mdi mdi-arrow-right-bold-circle-outline panah"></span>
	      	</li>
	      </a>
	     </ul>
	     </div>
	     
	      <div class="tab-pane" id="transfer">
       		
       			<ul class="list-group">
	       <a id="idmandiri">
	       	<li class="list-group-item metode-pembayaran row">
	       			<img class="img-metode-pembayaran" src="<?php echo base_url().'assets/img/mandiri.png'?>">
	       			<div class="col-md-8 ket-bayar">
	       				Mandiri
	       				<p>Transfer ke Rekening Mandiri</p>
	       			</div>
	       			<span class="mdi mdi-arrow-right-bold-circle-outline panah"></span>
	       		
	       </li>
	       </a>
		      <a id="idbri">
		      	<li class="list-group-item metode-pembayaran row">
		       		<img class="img-metode-pembayaran" src="<?php echo base_url().'assets/img/bri.png'?>">
		       		<div class="col-md-8 ket-bayar">
		       			BRI
		       			<p>Transfer ke Rekening BRI</p>
		       		</div>
		       		<span class="mdi mdi-arrow-right-bold-circle-outline panah"></span>
		      	</li>
		      </a>
		      <a  id="idjenius">
		      	<li class="list-group-item metode-pembayaran row">
		       			<img class="img-metode-pembayaran" src="<?php echo base_url().'assets/img/jenius.png'?>">
		       			<div class="col-md-8 ket-bayar">
		       				Jenius
		       				<p>Transfer ke Rekening Jenius</p>
		       			</div>
		       			<span class="mdi mdi-arrow-right-bold-circle-outline panah"></span>
		      	</li>
		      </a>
		     </ul>
       		
	      </div>
	      <div class="tab-pane" id="tf-mandiri">
	      	<div class="container-rek">
	      		<center>
	      		<div class="circle-pembayaran">
					<img class="img-bayar" src="<?php echo base_url().'assets/img/mandiri.png'?>">
				</div>
				<b><i><?php echo $i->id; ?></i></b>
				<div class="alert alert-info text-justify" style="margin-top: 10px;">
	       			<h5>Silahkan transfer ke nomor rekening <b>9000033856xxx</b> sesuai nominal total harga.</h5>
	    		</div>
				</center>
	      	</div>
	      </div>

	      <div class="tab-pane" id="tf-bri">
	      	<div class="container-rek">
	      		<center>
	      		<div class="circle-pembayaran">
					<img class="img-bayar" src="<?php echo base_url().'assets/img/bri.png'?>">
				</div>
				<b><i><?php echo $i->id; ?></i></b>
				<div class="alert alert-info text-justify" style="margin-top: 10px;">
	       			<h5>Silahkan transfer ke nomor rekening <b>100006576xxx</b> sesuai nominal total harga.</h5>
	    		</div>
				</center>
	      	</div>
	      </div>

	      <div class="tab-pane" id="tf-jenius">
	      	<div class="container-rek">
	      		<center>
	      		<div class="circle-pembayaran">
					<img class="img-bayar" src="<?php echo base_url().'assets/img/jenius.png'?>">
				</div>
				<b><i><?php echo $i->id; ?></i></b>
				<div class="alert alert-info text-justify" style="margin-top: 10px;">
	       			<h5>Silahkan transfer ke nomor rekening <b>$edwinrr</b> sesuai nominal total harga.</h5>
	    		</div>
				</center>
	      	</div>
	      </div>

	      <div class="tab-pane" id="tf-ovo">
	      	<div class="container-rek">
	      		<center>
	      		<div class="circle-pembayaran">
					<img class="img-bayar" src="<?php echo base_url().'assets/img/ovo.png'?>">
				</div>
				<b><i><?php echo $i->id; ?></i></b>
				<div class="alert alert-info text-justify" style="margin-top: 10px;">
	       			<h5>Silahkan transfer ke nomor OVO <b>085155022840</b> sesuai nominal total harga.</h5>
	    		</div>
				</center>
	      	</div>
	      </div>

	      <div class="tab-pane" id="tf-gopay">
	      	<div class="container-rek">
	      		<center>
	      		<div class="circle-pembayaran">
					<img class="img-bayar" src="<?php echo base_url().'assets/img/gopay.png'?>">
				</div>
				<b><i><?php echo $i->id; ?></i></b>
				<div class="alert alert-info text-justify" style="margin-top: 10px;">
	       			<h5>Silahkan transfer ke nomor GOPAY <b>085155022840</b> sesuai nominal total harga.</h5>
	    		</div>
				</center>
	      	</div>
	      </div>
	     </div>
	  
    	<div class="modal-footer">
           <h3 style="float: left;margin-top: 10px;">Total</h3><span style="font-size: 24px;"> Rp. <?php echo number_format($this->cart->total(), 0,',','.') ?></span>
        </div>
   </div>
  </div>
 </div>
</div>
<?php } ?>
<script type="text/javascript">
     $(document).ready(function () {
         $('#transfer').hide();
         $('#tf-mandiri').hide();
         $('#tf-bri').hide();
         $('#tf-jenius').hide();
         $('#tf-ovo').hide();
         $('#tf-gopay').hide();
     });

     $('#idtf').click(function () {
         $('#home').hide();
         $('#transfer').fadeIn();
     });

     $('#idovo').click(function () {
         $('#home').hide();
         $('#tf-ovo').fadeIn();
     });

     $('#idgopay').click(function () {
         $('#home').hide();
         $('#tf-gopay').fadeIn();
     });

     $('#idmandiri').click(function () {
         $('#tf-mandiri').fadeIn();
         $('#transfer').hide();
     });

     $('#idbri').click(function () {
         $('#tf-bri').fadeIn();
         $('#transfer').hide();
     });

     $('#idjenius').click(function () {
         $('#tf-jenius').fadeIn();
         $('#transfer').hide();
     });

     $('#btn-previous').click(function () {
         $('#home').fadeIn();
         $('#transfer').hide();
         $('#tf-mandiri').hide();
         $('#tf-bri').hide();
         $('#tf-jenius').hide();
         $('#tf-ovo').hide();
         $('#tf-gopay').hide();
     });

 </script>

	<!-- Load Footer -->
	<?php $this->load->view('user/partials/v_footer.php') ?> 
</body>
</html>