<!DOCTYPE html>
<html>
<head>
	<title>Checkout | Jahitinkuy</title>
	<!-- Load Head -->
	<?php $this->load->view('user/partials/v_head.php') ?>
	<style>
		.banner-home{
			background: url(<?php echo base_url('assets/img/banner1.png');  ?>);
			background-size: cover;
			background-repeat: no-repeat;
			padding: 170px 0;
		}

		.heading-text{
			width: 60%;
			color: white;
			font-family: 'heading-h1';
			font-size: 50px;
		}

		.container-section{
			width: 80%;
			margin: 50px 120px;

		}

		.maps{
			width: 100%;
			height: 465px;
		}

		.icon{
			font-size: 50px;
		}

		label{
			font-size: 16px;
			font-weight: normal;
		}

		.form-textarea{
			height: 100px !important;
		}

		.form-control{
			font-weight: 100;
			font-size: 14px;
			font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
		}

		.form-control:focus{
			border: 1px solid #717171;
			box-shadow: none;
		}

		.alamat{
			font-family: "Oswald";
		}

		.btn{
			background: #FF046E;
			margin: 30px 0px;
			color: white;
			transition: ease background 0.3s;
		}

		.btn:hover{
			background: #D60045;
			color: white;
		}
	</style>
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB714FYSyNLaFSgokXmhD-vGfUr0n0Cw08&callback=initMap" async defer>
		
	</script>
	<script type="text/javascript">
      function initMap() {
        var propertiPeta = {
		    center: new google.maps.LatLng(-7.837772,110.415277),
			zoom: 12,
		    mapTypeId:google.maps.MapTypeId.ROADMAP
		  };
		  
		  var peta = new google.maps.Map(document.getElementById("show_maps"), propertiPeta);
		  
		  // membuat Marker
		  var marker=new google.maps.Marker({
		      position: new google.maps.LatLng(-7.837772, 110.415277),
		      map: peta,
			  // Properti Animasi
		      animation: google.maps.Animation.BOUNCE
		  });
	}
	</script>
</head>

<body>
	<!-- Load Navbar -->
	<?php $this->load->view('user/partials/v_navbar.php') ?>
	<!-- Load Floating -->
	<?php $this->load->view('user/partials/v_floating.php') ?>

	<div class="container-banner">
		
			<!-- <iframe class="maps" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15810.080534074625!2d110.41600901376948!3d-7.840501446391974!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e7a56d7710fa747%3A0x6528af7f4029314a!2zN8KwNTAnMTYuMCJTIDExMMKwMjQnNTUuMCJF!5e0!3m2!1sid!2sid!4v1610773752268!5m2!1sid!2sid" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe> -->
			<div class="maps" id="show_maps"></div>
		
	</div>
	<section>
		<div class="container-section">
			<div class="row">
                    <div class="col-12">
                        <h2 class="contact-title">Email Kami</h2>
                    </div>
                    <div class="col-lg-8">
                        <div class="row">
							<div class="form-group col-md-6">
								<label for="fname">Nama Depan</label>
								<input type="hidden" name="id">
								<input class=" input-lg form-control" type="text" id="fname" name="nama" required="required">
							</div>
							<div class="form-group col-md-6">
								<label for="email">Email</label>
								<input class="form-control input-lg" type="email" name="email" required="email">
							</div>
						</div>
							<div class="form-group">
								<label for="phone">Subject</label>
								<input class="form-control input-lg" type="number" name="subject" required="number">
							</div>
						<div class="form-group">
							<label for="catatan">Pesan</label>
							<textarea class="form-control form-textarea" name="pesan" id="catatan"></textarea>
						</div>
						<button class="btn" type="button">Kirim <i class="mdi mdi-send"></i></button>
					</div>

                    <div class="col-lg-4 alamat">
                        <div class="media contact-info row">
                            <span class="mdi mdi-home icon col-sm-3"></span>
                            <div class="col-md8">
                                <h3>Bantul.</h3>
                                <p>Potorono Banguntapan Bantul Yogyakarta</p>
                            </div>
                        </div>
                        <div class="media contact-info row">
                            <span class="mdi mdi-phone icon col-sm-3"></span>
                            <div class="col-md8">
                                <h3>085155022840</h3>
                                <p>Buka setiap hari</p>
                            </div>
                        </div>
                        <div class="media contact-info row">
                            <span class="mdi mdi-email icon col-sm-3"></span>
                            <div class="col-md8">
                                <h3>Jahitinkuy@gmail.com</h3>
                                <p>Kirim via email untuk menanyakan lebih lanjut.</p>
                            </div>
                        </div>
                    </div>
                </div> 
		</div>
	</section>
	
	<!-- Load Footer -->
	<?php $this->load->view('user/partials/v_footer.php') ?>
</body>
</html>