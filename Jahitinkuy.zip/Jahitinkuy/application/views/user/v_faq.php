<!DOCTYPE html>
<html>
<head>
	<title>Checkout | Jahitinkuy</title>
	<!-- Load Head -->
	<?php $this->load->view('user/partials/v_head.php') ?>
	<style>

		@font-face {
       	 	font-family: heading-h1;
        	src: url(<?php echo base_url('assets/fonts/YuseiMagic-Regular.ttf');  ?>);
		}

		@font-face {
       	 	font-family: mdi;
        	src: url(<?php echo base_url('assets/mdi/fonts/materialdesignicons.webfont.ttf');  ?>);
		}

		.banner-home{
			background: url(<?php echo base_url('assets/img/banner1.png');  ?>);
			background-size: cover;
			background-repeat: no-repeat;
			padding: 170px 0;
		}

		.heading-text{
			width: 60%;
			color: white;
			font-family: 'heading-h1';
			font-size: 50px;
		}

		.container-section{
			width: 80%;
			margin: 50px 120px;

		}

		.faqHeader {
	        font-size: 27px;
	        margin: 20px;

	    }

	    .panel-heading [data-toggle="collapse"]:after {
	        /*font-family: 'mdi';
	        content: "mdi mdi-delete";*/ /* "play" icon */
	        float: right;
	        color: white;
	        font-size: 18px;
	        line-height: 22px;
	        /* rotate "play" icon from > (right arrow) to down arrow */
	        -webkit-transform: rotate(-90deg);
	        -moz-transform: rotate(-90deg);
	        -ms-transform: rotate(-90deg);
	        -o-transform: rotate(-90deg);
	        transform: rotate(-90deg);
	    }

	    .panel-heading [data-toggle="collapse"].collapsed:after {
	        /* rotate "play" icon from > (right arrow) to ^ (up arrow) */
	        -webkit-transform: rotate(90deg);
	        -moz-transform: rotate(90deg);
	        -ms-transform: rotate(90deg);
	        -o-transform: rotate(90deg);
	        transform: rotate(90deg);
	        color: white;
	    }

	    .panel-heading{
	    	background: #FF046E !important;
	    	color: white !important;
	    }
	</style>
</head>
<body>
	<!-- Load Navbar -->
	<?php $this->load->view('user/partials/v_navbar.php') ?>
	<!-- Load Floating -->
	<?php $this->load->view('user/partials/v_floating.php') ?>

	<div class="container-banner">
		<div class="banner banner-home">
			<center>
				<div class="heading-text">
					FREQUENTLY ASKED QUESTIONS
				</div>
			</center>

		</div>
	</div>
		<section>
					<div class="container-section">
						 <div class="panel-group" id="accordion">
					        <div class="faqHeader">Pertanyaan umum yang sering ditanyakan</div>
					        <div class="panel panel-default">
					            <div class="panel-heading">
					                <h5 class="panel-title">
					                    <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTen">Apakah ada biaya minimum untuk menggunakan layanan jahitinkuy?</a>
					                </h5>
					            </div>
					            <div id="collapseTen" class="panel-collapse collapse">
					                <div class="panel-body">
					                    <b>Jawaban:</b> Di jahitinkuy tidak ada biaya minimum untuk menjahit, berapapun jumlahnya pasti akan dikerjakan, asalkan dari pihak kami juga menerimanya 
					                </div>
					            </div>
					        </div>
					        <div class="panel panel-default">
					            <div class="panel-heading">
					                <h5 class="panel-title">
					                    <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseEleven">Berapa lama pengerjaan layanan jahitinkuy?</a>
					                </h5>
					            </div>
					            <div id="collapseEleven" class="panel-collapse collapse">
					                <div class="panel-body">
					                    <b>Jawaban:</b> Lama pengerjaan tergantung dari kerumitan yang tersedia ya, paling cepat sih satu hari langsung jadi kok
					                </div>
					            </div>
					        </div>
					        <div class="panel panel-default">
					            <div class="panel-heading">
					                <h5 class="panel-title">
					                    <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse12">Bagaimana cara bergabung menjadi mitra?</a>
					                </h5>
					            </div>
					            <div id="collapse12" class="panel-collapse collapse">
					                <div class="panel-body">
					                    <b>Jawaban:</b> Caranya cukup mudah kok, tinggal masukan lamaran anda ke email mitra.jahitinkuy@gmail.com atau langsung datang ke kantor ya
					                </div>
					            </div>
					        </div>
					        <div class="panel panel-default">
					            <div class="panel-heading">
					                <h5 class="panel-title">
					                    <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse14">Apakah ada biaya tambahan pada antar jemput pakaian?</a>
					                </h5>
					            </div>
					            <div id="collapse14" class="panel-collapse collapse">
					                <div class="panel-body">
					                    <b>Jawaban:</b> Tentu ada, setiap 1km = 1 ribu rupiah, tapi tenang, cuma dihitung perjalanan berangkatnya saja, tidak untuk pulang pergi
					                </div>
					            </div>
					        </div>
					        <div class="panel panel-default">
					            <div class="panel-heading">
					                <h5 class="panel-title">
					                    <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse15">Bagaimana cara membayar di jahitinkuy</a>
					                </h5>
					            </div>
					            <div id="collapse15" class="panel-collapse collapse">
					                <div class="panel-body">
					                    <b>Jawaban:</b> Caranya cukup mudah kok, tinggal transfer dengan atm atau bisa juga membayarnya dengan gopay atau ovo
					                </div>
					            </div>
					        </div>
					        <div class="panel panel-default">
					            <div class="panel-heading">
					                <h5 class="panel-title">
					                    <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse16">Apakah saya bisa membuat pakaian custom di Jahitinkuy?</a>
					                </h5>
					            </div>
					            <div id="collapse16" class="panel-collapse collapse">
					                <div class="panel-body">
					                    <b>Jawaban:</b> Tentu saja bisa nih, mau pakaian apa aja tinggal konsultasikan kepada pihak kami
					                </div>
					            </div>
					        </div>
					        <div class="panel panel-default">
					            <div class="panel-heading">
					                <h5 class="panel-title">
					                    <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse1">Bagaimana jika pakaian saya kurang sesuai dengan yang diinginkan?</a>
					                </h5>
					            </div>
					            <div id="collapse1" class="panel-collapse collapse">
					                <div class="panel-body">
					                    <b>Jawaban:</b> Tenang saja, kami memberikan garansi kepada pelanggan kok, jadi jangan kwatir kalau ada apa apa ya.
					                </div>
					            </div>
					        </div>		       
					    </div>
					</div>
					</div>
				</section>

	<!-- Load Footer -->
	<?php $this->load->view('user/partials/v_footer.php') ?>
</body>
</html>