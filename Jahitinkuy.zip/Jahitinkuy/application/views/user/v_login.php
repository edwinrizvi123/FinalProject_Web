<!DOCTYPE html>
<html>
<head>
	<title>Login | Jahitinkuy</title>
	<!-- Load Head -->
	<?php $this->load->view('user/partials/v_head.php') ?>
	<style>
		.button-login{
			background: #FF046E; 
			width: 50%;
			margin-top: 20px;
			color: white;
			transition: ease 0.3s;
		}

		.button-login:hover{
			background: #D60045;
			color: white;
		}
	</style>
</head>
<body style="background: url(<?php echo base_url('assets/img/bg_pattern1.jpg'); ?>);">
<!-- Load Navbar -->
<?php $this->load->view('user/partials/v_navbar.php') ?>
<?php if($this->session->flashdata('msg')){ ?>

    <div class="alert alert-warning text-center col-md-8" style="margin-top:10px !important; left: 210px; position: absolute;">
       <span class="mdi mdi-alert-circle-outline"></span><?php echo $this->session->flashdata('msg'); ?>
    </div><?php } ?>
<center>
<!-- Load Floating-->
<?php $this->load->view('user/partials/v_floating.php') ?>


<div class="container-login-custom" style="margin-top: 70px;">
	<div class="col-md-6 container-form-login">

			<h3>LOGIN</h3>
				<form action="<?php echo base_url ('index.php/login/login_user') ?>" method="post">
				  	<div class="form-group">
				    	<label for="email">Email address:</label>
				    	<input name="email" type="email" class="form-control" id="email">
				  	</div>
				  	<div class="form-group">
				    	<label for="pwd">Password:</label>
				    	<input name="password" type="password" class="form-control" id="pwd">
				  	</div>
				  	<button type="submit" class="btn btn-default button-login" style="float: right;">Masuk</button>
				</form>
				  	<center>
				  	<br><br><br><br><br>
					<p style="font-size: 16px;">Belum punya akun?</p>
					<a href="<?php echo base_url('index.php/user/signup'); ?>" class="btn btn-lg btn-default button-login" style="margin-top: 10px;">Daftar</a>
					</center>
		</div>
		<div class="col-md-6 container-banner-login">
			<img class="banner-login" src="<?php echo base_url('assets/img/banner_login_gopay.png'); ?>">
		</div>
	</div>
</center>
<?php $this->load->view('user/partials/v_footer.php') ?>
</body>
</html>