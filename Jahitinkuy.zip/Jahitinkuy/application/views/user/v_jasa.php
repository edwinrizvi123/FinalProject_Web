<!DOCTYPE html>
<html>
<head>
	<title>List Jasa | Jahitinkuy</title>
	<!-- Load Head -->
	<?php $this->load->view('user/partials/v_head.php') ?>
	<style>
		.container-login-custom,.container-form-login,.container-banner-login,.banner-login{
			height: 630px;
		}

		.list-jasa-items p{
			margin-top: 10px;
		}

		.add-to-cart{
			float: right;
			width: 120px;
			top: 30px;
			bottom: 10px;
		}

		.harga{
			font-size: 12px;
			border: 1px solid #FF046E;
			padding: 5px;
		}

		.input-group-addon{
			background: #FF046E;
			color: white;
			border: 1px solid #FF046E;
			transition: ease background 0.3s;
		}

		.input-group-addon:hover{
			background: #ED005C;
			color: #F5EA2F;
		}
	</style>
</head>
<body>
<!-- Load Navbar -->
<?php $this->load->view('user/partials/v_navbar.php') ?>
<?php $this->load->view('user/partials/v_floating.php') ?>
<div class="container-banner">
	<div style="background-size: contain; background-repeat: no-repeat;">
		<img class="banner" src="<?php echo base_url('assets/img/bannerovo.png');  ?>">
	</div>
</div>
	<div class="container">
		<center>
			<nav class="navbar" style="width:41%;margin-top: 20px;">
			  	<div class="container-fluid">
			    	<ul class="nav navbar-nav" >
			      		<li class="list-jasa-items">
			      			<a id="kat-permak"><img src="<?php echo base_url('assets/img/i-permak.png'); ?>"></a>
			      			<p>Permak</p>
			      		</li>
			      		<li class="list-jasa-items">
			      			<a id="kat-jahit"><img src="<?php echo base_url('assets/img/i-jahit.png'); ?>"></a>
			      			<p>Jahit</p>
			      		</li>
			      		<li class="list-jasa-items">
			      			<a id="kat-potong"><img src="<?php echo base_url('assets/img/i-potong.png'); ?>"></a>
			      			<p>Potong</p>
			      		</li>
			      		<li class="list-jasa-items">
			      			<a id="kat-resleting"><img src="<?php echo base_url('assets/img/i-resleting.png'); ?>"></a>
			      			<p>Resleting</p>
			      		</li>
			      		<li class="list-jasa-items">
			      			<a id="kat-kancing"><img src="<?php echo base_url('assets/img/i-kancing.png'); ?>"></a>
			      			<p>Kancing</p>
			      		</li>
			    	</ul>
			  	</div>
			</nav>
		</center>
		<div class="container-jasa" style="width: 100%;">
			<div class="row" style="width: 100%;margin: 0;">
				<?php
        		foreach($product as $p){ 
        		?>
				<div class="container-jasa-item col-md-6 <?php echo $p->jenis; ?>" style="width: 50%;border-bottom: 1px solid #a4b0be;padding: 20 0;">
					<div class="col-md-4">
						<div>
							<img class="container-jasa-item-img" src="<?php echo base_url(); ?>upload/<?php echo $p->gambar_jasa; ?>">
						</div>
					</div>
					<div class="col-md-8 container-jasa-item-desc" style="height: 150px">
						<h2><?php echo $p->kategori ?></h2>
						<p><?php echo $p->deskripsi ?></p>
						<div class="input-group add-to-cart">
      						<a href="<?php echo base_url().'index.php/checkout/addToCart/'.$p->id ?>" class="input-group-addon"><i class="mdi mdi-basket-plus-outline"></i></a>
      						<div id="email" class="form-control harga text-center" name="email" placeholder="Email">
      							<b><?php $harga=number_format($p->harga,0,",","."); ?>
                            Rp. <?php echo $harga; ?></b>
                            	
                            </div>
						</div>
					</div>
				</div>
				<?php 
        		} 
        		?>
			</div>
		</div>
	</div>
<?php $this->load->view('user/partials/v_footer.php') ?>
</body>
<script>
$('#kat-permak').click(function(){
   	if (this.click){
   		$('.Permak').fadeIn();
   		$('.Kancing').fadeOut('fast');
   		$('.Potong').fadeOut('fast');
   		$('.Resleting').fadeOut('fast');
   		$('.Jahit').fadeOut('fast');
    }
});
$('#kat-potong').click(function(){
   	if (this.click){
   		$('.Permak').fadeOut('fast');
   		$('.Kancing').fadeOut('fast');
   		$('.Potong').fadeIn();
   		$('.Resleting').fadeOut('fast');
   		$('.Jahit').fadeOut('fast');
    }
});
$('#kat-jahit').click(function(){
   	if (this.click){
   		$('.Permak').fadeOut('fast');
   		$('.Kancing').fadeOut('fast');
   		$('.Potong').fadeOut('fast');
   		$('.Resleting').fadeOut('fast');
   		$('.Jahit').fadeIn();
    }
});
$('#kat-resleting').click(function(){
   	if (this.click){
   		$('.Permak').fadeOut('fast');
   		$('.Kancing').fadeOut('fast');
   		$('.Potong').fadeOut('fast');
   		$('.Resleting').fadeIn();
   		$('.Jahit').fadeOut('fast');
    }
});
$('#kat-kancing').click(function(){
   	if (this.click){
   		$('.Permak').fadeOut('fast');
   		$('.Kancing').fadeIn();
   		$('.Potong').fadeOut('fast');
   		$('.Resleting').fadeOut('fast');
   		$('.Jahit').fadeOut('fast');
    }
});
</script>
</html>
