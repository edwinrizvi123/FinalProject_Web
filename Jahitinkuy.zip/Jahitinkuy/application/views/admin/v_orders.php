<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Load partials head -->
  <?php $this->load->view('admin/partials/_head.php') ?>
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/dataTables.bootstrap4.min.css' ?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/font-awesome/css/font-awesome.min.css' ?>" />
  <style>
    th{
      padding-right: 0 !important;
    }
  </style>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://lipis.github.io/bootstrap-sweetalert/dist/sweetalert.js"></script>
  <link rel="stylesheet" href="https://lipis.github.io/bootstrap-sweetalert/dist/sweetalert.css" />
</head>
<body class="sidebar-fixed">
  <div class="container-scroller">
    <!-- Load partial navbar -->
    <?php $this->load->view('admin/partials/_navbar.php') ?>
    <!-- end partial navbar -->
    <div class="container-fluid page-body-wrapper">
      <div class="row row-offcanvas row-offcanvas-right">
        <!-- Load partial setting-pannel -->
        <?php $this->load->view('admin/partials/_settings-panel.php') ?>
        <!-- end partial navbar -->

        <!-- Load partial sidebar -->
        <?php $this->load->view('admin/partials/_sidebar.php') ?>
        <!-- end partial sidebar -->
        <div class="content-wrapper">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">List Order : <?php echo $total ?></h4>
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                    <table id="order-listing" class="table table-striped sortable-table">
                      <thead>
                        <tr>
                            <th>Order #<i class="mdi mdi-menu-swap"></th>
                            <th>Id Pesanan<i class="mdi mdi-menu-swap"></th>
                            <th>Tanggal<i class="mdi mdi-menu-swap"></th>
                            <th>Kategori<i class="mdi mdi-menu-swap"></th>
                            <th>Jenis<i class="mdi mdi-menu-swap"></th>
                            <th>Harga<i class="mdi mdi-menu-swap"></th>
                            <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php foreach ($orders as $o) { ?>
                        <tr id="<?php echo $o->id; ?>">
                            <td><?php echo $o->id; ?></td>
                            <td><?php echo $o->id_pesanan; ?></td>
                            <td><?php echo $o->tanggal; ?></td>
                            <td><?php echo $o->nama_jasa; ?></td>
                            <td><?php echo $o->jenis; ?></td>
                            <td>Rp. <?php echo number_format($o->harga,0,',','.') ?></td>
                            <td>
                             <!--  <?php echo anchor('invoice/delete_order/'.$o->id,'<button class="btn btn-danger"><i class="mdi mdi-delete"></i></button>'); ?> -->
                             <button class="btn btn-danger hapus"><i class="mdi mdi-delete"></i></button>
                            </td>
                        </tr>
                      <?php } ?>
                      </tbody>
                    </table>                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!--  Load partial sidebar -->
        <?php $this->load->view('admin/partials/_footer.php') ?>
        <!-- end partial sidebar -->
      </div>
      <!-- row-offcanvas ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <script type="text/javascript">
    $(document).ready(function () {
      $('.hapus').click(function () {
      var id = $(this).parents("tr").attr("id");
        swal({
          title: "Apakah Anda yakin?",
          text: "Data yang dihapus tidak dapat dikembalikan",
          type: "warning",
          showCancelButton: true,
          cancelButtonClass: 'btn-white btn-md waves-effect',
          confirmButtonClass: 'btn-danger btn-md waves-effect waves-light',
          confirmButtonText: 'Hapus'
        },
      function(isConfirm) {
        if (isConfirm) {
        $.ajax({
          url: '<?php echo base_url('index.php/invoice/delete_order/') ?>'+id,
          type: 'DELETE',
          error: function() {
            alert('Something is wrong');
          },
          success: function(data) {
            $("#"+id).remove();
            swal("Terhapus!", "Data berhasil dihapus.", "success");
          }
        });
        } 
      });
      
        });   
    });
    </script>
  <!-- container-scroller -->
  <!-- Load partial sidebar -->
  <?php $this->load->view('admin/partials/_js.php') ?>
  <!-- end partial sidebar -->
  <script src="<?php echo base_url().'assets/js/jquery.dataTables.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/dataTables.bootstrap4.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/data-table.js' ?>"></script>

  
</body>

</html>
