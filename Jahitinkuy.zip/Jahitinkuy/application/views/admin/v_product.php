<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Load partials head -->
  <?php $this->load->view('admin/partials/_head.php') ?>
  
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/all.css' ?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/select2.min.css' ?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/bootstrap-select2.min.css' ?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/dropify.min.css' ?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/dataTables.bootstrap4.min.css' ?>">
  <style>
    th{
      padding-right: 0px !important;
    }

    td{
      padding-right: 5px !important;
    }

    .col-desc{
      width: 300px;
    }

    .btn-add-jasa{
      margin-bottom: 30px;
    }

    .modal-content{
      background: #FFFFFF;
    }

    .form-control{
      height: 40px;
    }

    .form-control-textarea{
      height: 80px !important;
    }

    .input-upper{
      text-transform: uppercase
    }

    .btn-action{
      width: 35px !important;
      height: 30px;
      padding: 10px !important;
    }
  </style>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://lipis.github.io/bootstrap-sweetalert/dist/sweetalert.js"></script>
  <link rel="stylesheet" href="https://lipis.github.io/bootstrap-sweetalert/dist/sweetalert.css" />
</head>
<body class="sidebar-fixed">
  <div class="container-scroller">
    <!-- Load partial navbar -->
    <?php $this->load->view('admin/partials/_navbar.php') ?>
    <!-- end partial navbar -->
    <div class="container-fluid page-body-wrapper">
      <div class="row row-offcanvas row-offcanvas-right">
        <!-- Load partial setting-pannel -->
        <?php $this->load->view('admin/partials/_settings-panel.php') ?>
        <!-- end partial navbar -->

        <!-- Load partial sidebar -->
        <?php $this->load->view('admin/partials/_sidebar.php') ?>
        <!-- end partial sidebar -->
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Produk Jasa : <?php echo $total; ?></h4>
                  <div class="btn-group mr-2 btn-add-jasa">
                      <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#modalAdd"><i class="mdi mdi-plus-circle-outline"></i> Add</button>
                  </div>
                  <div class="table-responsive">
                    <table id="order-listing" class="table table-bordered">
                      <thead>
                        <tr>
                          <th class="text-center">
                            Foto<i class="mdi mdi-menu-swap">
                          </th>
                          <th>
                            Kode<i class="mdi mdi-menu-swap">
                          </th>
                          <th>
                            Kategori<i class="mdi mdi-menu-swap">
                          </th>
                          <th>
                            Jenis<i class="mdi mdi-menu-swap">
                          </th>
                          <th>
                            Harga<i class="mdi mdi-menu-swap">
                          </th>
                          <th class="col-desc">
                            Deskripsi<i class="mdi mdi-menu-swap">
                          </th>
                          <th style="width: 90px">
                            Action
                          </th>
                        </tr>
                      </thead>
                      
                      <tbody>
                      <?php
                        foreach($product as $products){
                      ?>
                        <tr id="<?php echo $products->id; ?>">
                          <td class="py-1 text-center">
                            <img src="<?php echo base_url().'upload/'; ?><?php echo $products->gambar_jasa; ?>" alt="image"/>
                          </td>
                          <td>
                            <?php echo $products->kode_jasa; ?>
                          </td>
                          <td>
                            <?php echo $products->kategori; ?>
                          </td>
                          <td>
                              <?php echo $products->jenis; ?>
                          </td>
                          <td>
                            <?php $harga=number_format($products->harga,0,",","."); ?>
                            Rp. <?php echo $harga; ?>
                          </td>
                          <td>
                            <?php echo $products->deskripsi; ?>
                          </td>
                          <td>
                            <div class="btn-group" role="group" aria-label="Second group">
                              <button class="btn btn-success btn-action " data-toggle="modal" data-target="#modalEdit<?php echo $products->id; ?>">
                                <i class="mdi mdi-pencil"></i>
                              </button>
                              <button type="button" class="btn btn-danger btn-action hapus">
                                <i class="mdi mdi-delete"></i>
                              </button>
                            </div>
                          </td>
                        </tr>
                        <?php } ?>
                      </tbody>
                      
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!--  Load partial footer -->
        <?php $this->load->view('admin/partials/_footer.php') ?>
        <!-- end partial footer -->
      </div>
    </div>
  </div>
  <!-- Modal Add -->
  <div class="modal fade" id="modalAdd" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h3>Tambah Jasa</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="<?php echo base_url().'index.php/page/insert_product' ?>" method="post" enctype="multipart/form-data">
          <div class="row grid-margin">
            <div class="col-8">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Detail Jasa</h4>
                  <div class="form-group row">
                    <div class="col-lg-3">
                      <label class="col-form-label">Kode</label>
                    </div>
                    <div class="col-lg-8">
                      <input class="form-control input-upper border-info" maxlength="10" name="kode_jasa" id="defaultconfig" type="text" placeholder="Maksimal 10 karakter.">
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-lg-3">
                      <label class="col-form-label">Kategori</label>
                    </div>
                    <div class="col-lg-8">
                      <input class="form-control border-info" maxlength="25" name="kategori" id="defaultconfig" type="text" placeholder="Maksimal 25 karakter.">
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-lg-3">
                      <label class="col-form-label">Jenis</label>
                    </div>
                    <div class="col-lg-8"> 
                        <select class="form-control border-info" style="width:100%" name="jenis">
                          <option value="Permak">Permak</option>
                          <option value="Jahit">Jahit</option>
                          <option value="Obras">Obras</option>
                          <option value="Kancing">Kancing</option>
                          <option value="Resleting">Resleting</option>
                        </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-lg-3">
                      <label class="col-form-label">Harga</label>
                    </div>
                    <div class="col-lg-8">
                      <div class="input-group">
                          <div class="input-group-prepend">
                            <span class="input-group-text">Rp</span>
                          </div>
                          <input type="number" class="form-control form-control-sm uang" name="harga" />
                    </div>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-lg-3">
                      <label class="col-form-label">Deskripsi</label>
                    </div>
                    <div class="col-lg-8">
                      <textarea id="maxlength-textarea" class="form-control form-control-textarea border-info" maxlength="100" rows="2" placeholder="Maksimal 100 karakter." name="deskripsi"></textarea>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title d-flex">Gambar Jasa
                  </h4>
                  <input type="file" class="dropify" name="upload" required />
                </div>
              </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Submit</button>
          <button type="button" class="btn btn-light" data-dismiss="modal">Cancel</button>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>
  <!-- Modal Ends -->

  <!-- Modal Edit -->
  <?php
    foreach($product as $productedit){
  ?>
  <div class="modal fade" id="modalEdit<?php echo $productedit->id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h3>Edit Jasa</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="<?php echo base_url().'index.php/page/update_jasa' ?>" method="post" enctype="multipart/form-data">
          <div class="row grid-margin">
            <div class="col-8">
              <div class="card">
                <div class="card-body">
                  
                  <h4 class="card-title">Detail Jasa</h4>
                  <div class="form-group row">
                    <div class="col-lg-3">
                      <label class="col-form-label">Kode</label>
                    </div>
                    <div class="col-lg-8">
                      <input type="hidden" name="id" value="<?php echo $productedit->id ?>">
                      <input class="form-control input-upper border-info" maxlength="10" name="kode_jasa" id="defaultconfig" type="text" placeholder="Maksimal 10 karakter." value="<?php echo $productedit->kode_jasa ?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-lg-3">
                      <label class="col-form-label">Kategori</label>
                    </div>
                    <div class="col-lg-8">
                      <input class="form-control border-info" maxlength="25" name="kategori" id="defaultconfig" type="text" placeholder="Maksimal 25 karakter." value="<?php echo $productedit->kategori ?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-lg-3">
                      <label class="col-form-label">Jenis</label>
                    </div>
                    <div class="col-lg-8"> 
                        <select class="form-control border-info" style="width:100%" name="jenis">
                          <option value="Permak">Permak</option>
                          <option value="Jahit">Jahit</option>
                          <option value="Obras">Obras</option>
                          <option value="Kancing">Kancing</option>
                          <option value="Resleting">Resleting</option>
                        </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-lg-3">
                      <label class="col-form-label">Harga</label>
                    </div>
                    <div class="col-lg-8">
                      <div class="input-group">
                          <div class="input-group-prepend">
                            <span class="input-group-text">Rp</span>
                          </div>
                          <input type="number" class="form-control form-control-sm uang" name="harga" value="<?php echo $productedit->harga ?>"/>
                    </div>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-lg-3">
                      <label class="col-form-label">Deskripsi</label>
                    </div>
                    <div class="col-lg-8">
                      <textarea id="maxlength-textarea" class="form-control form-control-textarea border-info" maxlength="100" rows="2" placeholder="Maksimal 100 karakter." name="deskripsi"><?php echo $productedit->deskripsi ?></textarea>
                    </div>
                  </div>
                
                </div>
              </div>
            </div>
            <div class="col-lg-4 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title d-flex">Gambar Jasa
                  </h4>
                  <input type="file" class="dropify" name="upload" value="<?php echo base_url().'upload/'; ?><?php echo $products->gambar_jasa; ?>" required />
                </div>
              </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Submit</button>
          <button type="button" class="btn btn-light" data-dismiss="modal">Cancel</button>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php } ?>
  <!-- Modal Ends -->

  <script type="text/javascript">
    $(document).ready(function () {
      $('.hapus').click(function () {
      var id = $(this).parents("tr").attr("id");
        swal({
          title: "Apakah Anda yakin?",
          text: "Data yang dihapus tidak dapat dikembalikan",
          type: "warning",
          showCancelButton: true,
          cancelButtonClass: 'btn-white btn-md waves-effect',
          confirmButtonClass: 'btn-danger btn-md waves-effect waves-light',
          confirmButtonText: 'Hapus'
        },
      function(isConfirm) {
        if (isConfirm) {
        $.ajax({
          url: '<?php echo site_url('page/delete_product/') ?>'+id,
          type: 'DELETE',
          error: function() {
            alert('Something is wrong');
          },
          success: function(data) {
            $("#"+id).remove();
            swal("Terhapus!", "Data berhasil dihapus.", "success");
          }
        });
        } 
      });
      
        });   
    });
    </script>


  <!-- Load partial sidebar -->
  <?php $this->load->view('admin/partials/_js.php') ?>
  <!-- end partial sidebar -->
  
  <script src="<?php echo base_url().'assets/js/select2.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/select2.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/typehead.js' ?>"></script>
  <script src="<?php echo base_url().'assets/dropify/dropify.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/dropify.js' ?>"></script>
  <script src="<?php echo base_url().'assets/validation/jquery.validate.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/validation/bootstrap-maxlength.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/form-validation' ?>"></script>
  <script src="<?php echo base_url().'assets/js/bt-maxlength.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/typehead.bundle.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/jquery.dataTables.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/dataTables.bootstrap4.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/data-table.js' ?>"></script>


</body>

</html>
