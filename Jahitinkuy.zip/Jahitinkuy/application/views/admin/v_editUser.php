<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Load partials head -->
  <?php $this->load->view('admin/partials/_head.php') ?>
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/all.css' ?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/select2.min.css' ?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/bootstrap-select2.min.css' ?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/bootstrap-datepicker.min.css' ?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/dropify.min.css' ?>">
  <style type="text/css">
    
    .form-control{
      height: 37px !important;
    }

    .btn-save{
      margin-top: 20px !important;
    }

    .list-warning{
      text-decoration: none !important;
    }

  </style>
  
</head>
<body class="sidebar-fixed">
  

  <div class="container-scroller">
    <!-- Load partial navbar -->
    <?php $this->load->view('admin/partials/_navbar.php') ?>
    <!-- end partial navbar -->
    <div class="container-fluid page-body-wrapper">
      <div class="row row-offcanvas row-offcanvas-right">
        <!-- Load partial setting-pannel -->
        <?php $this->load->view('admin/partials/_settings-panel.php') ?>
        <!-- end partial navbar -->

        <!-- Load partial sidebar -->
        <?php $this->load->view('admin/partials/_sidebar.php') ?>
        <!-- end partial sidebar -->
        

        <div class="content-wrapper">
          <div class="row">
            <div class="col-12 grid-margin">
              <div class="card">
                <?php
                $errors = $this->session->flashdata('errors');
                if(!empty($errors)){ ?>
                  <div id="target" class="alert alert-fill-danger" role="alert">
                    <h4><i class="mdi mdi-alert-circle"></i>
                    Ups! Ada kesalahan saat menginputkan data. 
                    <button onclick="fungsiSaya()" type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    </h4>
                    
                    <ul class="list-warning">
                      <?php foreach ($errors as $error) : ?>
                      <br><i class="mdi mdi-alert-circle"></i><?= ($error) ?>
                       <?php endforeach ?>
                    </ul>
                    <script>
                      function fungsiSaya() {
                        var x = document.getElementById("target");
                        if (x.style.display === "none") {
                          x.style.display = "block";
                        } else {
                          x.style.display = "none";
                        }
                      }
                    </script>
                  </div>
                <?php }?>
                <div class="card-body">
                  <h4 class="card-title">Edit User</h4>
                  <?php foreach($user as $usr) { ?>
                  <form class="form-sample" action="<?php echo base_url().'index.php/page/update_user' ?>" method="post">
                    
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Nama Depan</label>
                          <div class="col-sm-9">
                            <input type="hidden" name="id" value="<?php echo $usr->id ?>">
                            <input id="firstname" type="text" class="form-control border-info" name="fName" value="<?php echo $usr->nm_depan ?>" />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Nama Belakang</label>
                          <div class="col-sm-9">
                            <input id="lastname" type="text" class="form-control border-info" name="lName" value="<?php echo $usr->nm_belakang ?>" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Jenis Kelamin</label>
                          <div class="col-sm-9">
                            <select class="form-control border-info" name="gender" value="<?php echo $usr->jns_kelamin ?>">
                              <option>Laki-laki</option>
                              <option>Perempuan</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Tanggal Lahir</label>
                          <div class="col-sm-9">
                            <div id="datepicker-popup" class="input-group date datepicker">
                              <input type="text" class="form-control border-info" name="bday" id="bday" value="<?php echo $usr->tgl_lahir ?>">
                              <div class="input-group-addon input-group-text">
                                <span class="mdi mdi-calendar"></span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label for="email" class="col-sm-3 col-form-label">Email</label>
                          <div class="col-sm-9">
                            <input id="email" type="email" class="form-control border-info" name="email" value="<?php echo $usr->email ?>" />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Password</label>
                          <div class="col-sm-9">
                            <input type="password" class="form-control border-info" name="password"  />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label"></label>
                          <div class="col-sm-9">
                            <button type="submit" class="btn btn-info btn-fw btn-save">Save</button>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Konfirmasi Password</label>
                          <div class="col-sm-9">
                            <input type="password" class="form-control border-info" name="confirm-password"  />
                          </div>
                        </div>
                      </div>
                    </div>
                  <?php } ?>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- content-wrapper ends -->
        <!--  Load partial footer -->
        <?php $this->load->view('admin/partials/_footer.php') ?>
        <!-- end partial footer -->
      </div>
      <!-- row-offcanvas ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  
  
  
  <!-- Load partial sidebar -->
  <?php $this->load->view('admin/partials/_js.php') ?>
  <!-- end partial sidebar -->

  <script src="<?php echo base_url().'assets/js/select2.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/select2.js' ?>"></script>
  <script src="<?php echo base_url().'assets/validation/jquery.validate.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/validation/bootstrap-maxlength.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/form-validation' ?>"></script>
  <script src="<?php echo base_url().'assets/js/bt-maxlength.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/typehead.js' ?>"></script>
  <script src="<?php echo base_url().'assets/dropify/dropify.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/dropify.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/bootstrap-datepicker.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/formpickers.js' ?>"></script>

  <script>
    $( function() {
      $( "#bday" ).datepicker({
        autoclose:true,
        todayHighlight:true,
        format:'yyyy-mm-dd',
        language: 'id'
      });
    } );
  </script>
  
</body>

</html>
