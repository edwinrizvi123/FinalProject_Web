<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Load partials head -->
  <?php $this->load->view('admin/partials/_head.php') ?>
</head>
<body class="sidebar-fixed">
  <div class="container-scroller">
    <!-- Load partial navbar -->
    <?php $this->load->view('admin/partials/_navbar.php') ?>
    <!-- end partial navbar -->
    <div class="container-fluid page-body-wrapper">
      <div class="row row-offcanvas row-offcanvas-right">
        <!-- Load partial setting-pannel -->
        <?php $this->load->view('admin/partials/_settings-panel.php') ?>
        <!-- end partial navbar -->

        <!-- Load partial sidebar -->
        <?php $this->load->view('admin/partials/_sidebar.php') ?>
        <!-- end partial sidebar -->


        <div class="content-wrapper">
          <!-- Error admin -->
          <?php
              $errors = $this->session->flashdata('errors_admin');
                if(!empty($errors)){ ?>
                  <div id="target1" class="alert alert-fill-info" role="alert">
                    <h4><i class="mdi mdi-alert-circle"></i>
                    Ups! Ada kesalahan saat menginputkan data. 
                    <button onclick="fungsiSaya()" type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    </h4>
                    
                    <ul class="list-warning">
                      <?php foreach ($errors as $error) : ?>
                      <br><i class="mdi mdi-alert-circle"></i><?= ($error) ?>
                       <?php endforeach ?>
                    </ul>
                    <script>
                      function fungsiSaya() {
                        var x = document.getElementById("target1");
                        if (x.style.display === "none") {
                          x.style.display = "block";
                        } else {
                          x.style.display = "none";
                        }
                      }
                    </script>
                    <script>
                      $('modalCreateAdmin').modal('show');
                    </script>
                  </div>
          <?php }?>
          <!-- Error user -->
          <?php
              $errors = $this->session->flashdata('errors_user');
                if(!empty($errors)){ ?>
                  <div id="target1" class="alert alert-fill-info" role="alert">
                    <h4><i class="mdi mdi-alert-circle"></i>
                    Ups! Ada kesalahan saat menginputkan data. 
                    <button onclick="fungsiSaya()" type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    </h4>
                    
                    <ul class="list-warning">
                      <?php foreach ($errors as $error) : ?>
                      <br><i class="mdi mdi-alert-circle"></i><?= ($error) ?>
                       <?php endforeach ?>
                    </ul>
                    <script>
                      function fungsiSaya() {
                        var x = document.getElementById("target1");
                        if (x.style.display === "none") {
                          x.style.display = "block";
                        } else {
                          x.style.display = "none";
                        }
                      }
                    </script>
                    <script>
                      $('modalCreateAdmin').modal('show');
                    </script>
                  </div>
          <?php }?>
          <div class="row">
            <div class="col-md-6 col-lg-3 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex align-items-center justify-content-md-center">
                    <i class="mdi mdi-basket icon-lg text-success"></i>
                    <div class="ml-3">
                      <p class="mb-0">Pesanan</p>
                      <h6><?php echo $total_pesanan ?></h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-3 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex align-items-center justify-content-md-center">
                    <i class="mdi mdi-rocket icon-lg text-warning"></i>
                    <div class="ml-3">
                      <p class="mb-0">Invoice</p>
                      <h6><?php echo $total_invoice ?></h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-3 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex align-items-center justify-content-md-center">
                    <i class="mdi mdi-diamond icon-lg text-info"></i>
                    <div class="ml-3">
                      <p class="mb-0">Jasa terjual</p>
                      <h6><?php echo $total_terjual ?></h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-3 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex align-items-center justify-content-md-center">
                    <i class="mdi mdi-chart-line-stacked icon-lg text-danger"></i>
                    <div class="ml-3">
                      <p class="mb-0">Total Pendapatan</p>
                      <h6>Rp. <?php
                      $total_pendapatan = $total_harga * $total_terjual;
                      echo number_format($total_pendapatan,0,',','.') ?>,-</h6>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!--  Load partial footer -->
        <?php $this->load->view('admin/partials/_footer.php') ?>
        <!-- end partial footer -->
      </div>
      <!-- row-offcanvas ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- Load partial sidebar -->
  <?php $this->load->view('admin/partials/_js.php') ?>
  <!-- end partial sidebar -->
  <!-- Custom js for this page-->
  <script src="<?php echo base_url().'assets/js/dashboard.js' ?>"></script>
  <!-- End custom js for this page-->
</body>

</html>
