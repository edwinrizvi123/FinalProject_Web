<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Load partials head -->
  <?php $this->load->view('admin/partials/_head.php') ?>
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/all.css' ?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/dataTables.bootstrap4.min.css' ?>">
  <style type="text/css">
    .btn-action{
      width: 35px !important;
      height: 30px;
      padding: 10px !important;
      color: white;
    }
  </style>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://lipis.github.io/bootstrap-sweetalert/dist/sweetalert.js"></script>
  <link rel="stylesheet" href="https://lipis.github.io/bootstrap-sweetalert/dist/sweetalert.css" />
</head>
<body class="sidebar-fixed">
  <div class="container-scroller">
    <!-- Load partial navbar -->
    <?php $this->load->view('admin/partials/_navbar.php') ?>
    <!-- end partial navbar -->
    <div class="container-fluid page-body-wrapper">
      <div class="row row-offcanvas row-offcanvas-right">
        <!-- Load partial setting-pannel -->
        <?php $this->load->view('admin/partials/_settings-panel.php') ?>
        <!-- end partial navbar -->

        <!-- Load partial sidebar -->
        <?php $this->load->view('admin/partials/_sidebar.php') ?>
        <!-- end partial sidebar -->
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Users Registered : <?php echo $total; ?></h4>
                  <div class="table-responsive">
                    <table id="order-listing" class="table table-striped">
                      <thead>
                        <tr>
                          <th>
                            Nama<i class="mdi mdi-menu-swap">
                          </th>
                          <th>
                            Email<i class="mdi mdi-menu-swap">
                          </th>
                          <th>
                            Jenis Kelamin<i class="mdi mdi-menu-swap">
                          </th>
                          <th>
                            Tanggal Lahir<i class="mdi mdi-menu-swap">
                          </th>
                          <th class="text-center">
                            Action
                          </th>
                        </tr>
                      </thead>
                      
                      <tbody>
                      <?php
                        foreach($user as $usr){
                      ?>
                        <tr id="<?php echo $usr->id ?>" >
                          <td>
                            <?php echo $usr->nm_depan ?> <?php echo $usr->nm_belakang ?>
                          </td>
                          <td>
                            <?php echo $usr->email ?>
                          </td>
                          <td>
                            <?php echo $usr->jns_kelamin ?>
                          </td>
                          <td>
                            <?php echo $usr->tgl_lahir ?>
                          </td>
                          <td class="text-center">
                            <div class="btn-group" role="group" aria-label="Second group">
                              <?php echo anchor('page/edit_user/'.$usr->id,'<div class="btn btn-success btn-action"><i class="mdi mdi-pencil" style="color: white"></i></div>') ?>
                              
                              <button type="button" class="btn btn-danger btn-action hapus">
                                <i class="mdi mdi-delete"></i>
                              </button>
                            </div>
                          </td>
                        </tr>
                      <?php } ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!--  Load partial footer -->
        <?php $this->load->view('admin/partials/_footer.php') ?>
        <!-- end partial footer -->
      </div>
      <!-- row-offcanvas ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <script type="text/javascript">
    $(document).ready(function () {
      $('.hapus').click(function () {
      var id = $(this).parents("tr").attr("id");
        swal({
          title: "Apakah Anda yakin?",
          text: "Data yang dihapus tidak dapat dikembalikan",
          type: "warning",
          showCancelButton: true,
          cancelButtonClass: 'btn-white btn-md waves-effect',
          confirmButtonClass: 'btn-danger btn-md waves-effect waves-light',
          confirmButtonText: 'Hapus'
        },
      function(isConfirm) {
        if (isConfirm) {
        $.ajax({
          url: '<?php echo site_url('page/delete_user/') ?>'+id,
          type: 'DELETE',
          error: function() {
            alert('Something is wrong');
          },
          success: function(data) {
            $("#"+id).remove();
            swal("Terhapus!", "Data berhasil dihapus.", "success");
          }
        });
        } 
      });
      
        });   
    });
    </script>

  <!-- Load partial sidebar -->
  <?php $this->load->view('admin/partials/_js.php') ?>
  <!-- end partial sidebar -->
  <script src="<?php echo base_url().'assets/js/jquery.dataTables.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/dataTables.bootstrap4.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/data-table.js' ?>"></script>
</body>

</html>
