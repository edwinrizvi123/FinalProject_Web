<!DOCTYPE html>
<html>
<head>
	<title>Login Admin</title>
  <?php $this->load->view('admin/partials/_head.php') ?>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/login.css' ?>">
  <style>
    .btn{
      background: linear-gradient(88deg, #13b4ca, #18cabe);
    }
  </style>
</head>
<body>
	<div class="login">
	<h1>Login</h1>
		<?php
      if($this->session->flashdata('msg')){
    ?>
      <div class="alert alert-warning text-center" style="margin-top:20px;">
        <span class="glyphicon glyphicon-remove"></span><?php echo $this->session->flashdata('msg'); ?>
      </div>
    <?php } ?>
    <form method="post" action="<?php echo base_url().'index.php/login/auth' ?>">
    	<input type="text" name="username" placeholder="Username" required="required" />
      <input type="password" name="password" placeholder="Password" required="required" />
      <button type="submit" class="btn btn-primary btn-block btn-large">Login</button>
    </form>
</div>
</body>
</html>
