  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Jahitinkuy - Admin</title>
  <!-- plugins:css -->

  <link rel="stylesheet" href="<?php echo base_url().'assets/mdi/css/materialdesignicons.min.css' ?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/flag-icon-css/css/flag-icon.min.css' ?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/perfect-scrollbar/css/perfect-scrollbar.min.css' ?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/simple-line-icons/css/simple-line-icons.css' ?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/feather.css' ?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/vendor.bundle.base.css' ?>">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/font-awesome/css/font-awesome.min.css' ?>" />
  <link rel="stylesheet" href="<?php echo base_url().'assets/jquery-bar-rating/dist/themes/fontawesome-stars.css' ?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/simple-line-icons/css/simple-line-icons.css' ?>">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <!-- <link rel="stylesheet" href="<?php echo base_url().'assets/css/bootstrap.css' ?>"> -->
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/style.css' ?>">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?php echo base_url().'assets/img/favicon3.png' ?>" />

  