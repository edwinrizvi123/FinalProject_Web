



<!-- Modal Add -->
          <div class="modal fade" id="modalCreateUser" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
            <div class="modal-dialog modal-lg" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h3>Tambah User</h3>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <form class="form-sample" action="<?php echo base_url().'index.php/page/insert_user' ?>" method="post">
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Nama Depan</label>
                          <div class="col-sm-9">
                            <input id="firstname" type="text" class="form-control border-info" name="fName" />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Nama Belakang</label>
                          <div class="col-sm-9">
                            <input id="lastname" type="text" class="form-control border-info" name="lName" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Jenis Kelamin</label>
                          <div class="col-sm-9">
                            <select class="form-control border-info" name="gender">
                              <option>Laki-laki</option>
                              <option>Perempuan</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Tanggal Lahir</label>
                          <div class="col-sm-9">
                            <div id="datepicker-popup" class="input-group date datepicker">
                              <input type="text" class="form-control border-info" name="bday" id="bday" >
                              <div class="input-group-addon input-group-text">
                                <span class="mdi mdi-calendar"></span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label for="email" class="col-sm-3 col-form-label">Email</label>
                          <div class="col-sm-9">
                            <input id="email" type="email" class="form-control border-info" name="email"  />
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Password</label>
                          <div class="col-sm-9">
                            <input type="password" class="form-control border-info" name="password"  />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label"></label>
                          <div class="col-sm-9">
                            <button type="submit" class="btn btn-info btn-fw btn-save">Save</button>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group row">
                          <label class="col-sm-3 col-form-label">Konfirmasi Password</label>
                          <div class="col-sm-9">
                            <input type="password" class="form-control border-info" name="confirm-password"  />
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
            <!-- Modal Ends -->

            <!-- Modal Add -->
          <div class="modal fade" id="modalCreateAdmin" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                
                  <div class="col-md-12 grid-margin stretch-card">
                    <div class="card">
                      <div class="card-body">
                        <h4 class="card-title">Tambah Admin</h4>

                        <form class="forms-sample" action="<?php echo base_url().'index.php/page/insert_admin' ?>" method="post">
                          <div class="form-group">
                            <label for="exampleInputName1">Nama</label>
                            <input type="text" name="nama" class="form-control" id="exampleInputName1" placeholder="Name">
                          </div>
                          <div class="form-group">
                            <label for="exampleInputEmail3">Email</label>
                            <input type="email" name="email" class="form-control" id="exampleInputEmail3" placeholder="Email">
                          </div>
                          <div class="form-group">
                            <label for="exampleInputEmail3">Username</label>
                            <input type="text" name="username" class="form-control" id="exampleInputEmail3" placeholder="Username">
                          </div>
                          <div class="form-group">
                            <label for="exampleInputPassword4">Password</label>
                            <input type="password" name="password" class="form-control" id="exampleInputPassword4" placeholder="Password">
                          </div>
                          <div class="form-group">
                          <label>Level</label>
                                <select class="form-control" name="level">
                                  <option value="1">1 (Super Admin)</option>
                                  <option value="2">2 (Admin)</option>
                                </select>
                          </div>
                          
                          <button type="submit" class="btn btn-success mr-2">Submit</button>
                          <button class="btn btn-light" data-dismiss="modal" aria-label="Close">Cancel</button>
                        </form>
                      </div>
                    </div>
                  </div>
              </div>
            </div>
          </div>
            <!-- Modal Ends -->


            

            <!-- <script>
              window.setTimeout(function() {
                $(".alert").fadeTo(500, 0).slideUp(500, function(){
                    $(this).remove(); 
                });
              }, 7000);
            </script> -->
            