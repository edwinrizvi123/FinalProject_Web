        <nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <div class="nav-link">
                <div class="profile-image">
                  <?php 

                      if($this->session->userdata('akses')=='1'){ ?>
                        <img src="<?php echo base_url().'assets/img/super_admin.png' ?>" alt="image"/>
                     <?php }else{ ?>
                        <img src="<?php echo base_url().'assets/img/admin.png' ?>" alt="image"/>
                    <?php }

                    ?>
                  
                  <span class="online-status online"></span> <!--change class online to offline or busy as needed-->

                </div>
                <div class="profile-name">
                  <p class="name">
                    <?php echo $this->session->userdata('ses_nama');?>
                  </p>
                  <p class="designation">
                    <?php 

                      if($this->session->userdata('akses')=='1'){
                        echo 'Super Admin';
                      }else{
                        echo 'Admin';
                      }

                    ?>
                  </p>
                </div>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url().'index.php/page' ?>">
                <i class="icon-rocket menu-icon"></i>
                <span class="menu-title">Dashboard</span>
                <span class="badge badge-success">New</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="collapse" href="#page-layouts1" aria-expanded="false" aria-controls="page-layouts">
                <i class="icon-bag menu-icon"></i>
                <span class="menu-title">Invoice</span>
                <span class="badge badge-danger">2</span>
              </a>
              <div class="collapse" id="page-layouts1">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item d-none d-lg-block"> 
                    <a class="nav-link" href="<?php echo base_url().'index.php/page/orders' ?>">
                      <span class="menu-title">Orders</span>
                    </a>
                  </li>
                  <li class="nav-item d-none d-lg-block"> 
                    <a class="nav-link" href="<?php echo base_url().'index.php/page/invoice' ?>">
                      <span class="menu-title">Invoice</span>
                    </a>
                  </li>
                </ul>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url().'index.php/page/users' ?>">
                <i class="icon-user menu-icon"></i>
                <span class="menu-title">Users</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url().'index.php/page/product' ?>">
                <i class="icon-tag menu-icon"></i>
                <span class="menu-title">Product</span>
              </a>
            </li>
          </ul>
        </nav>