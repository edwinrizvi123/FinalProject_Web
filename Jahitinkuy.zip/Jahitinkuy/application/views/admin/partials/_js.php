<!-- plugins:js -->
  <script src="<?php echo base_url().'assets/jquery/jquery.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/vendor.bundle.base.js' ?>"></script>
  <!-- <script src="<?php echo base_url().'assets/bootstrap/js/bootstrap.bundle.min.js' ?>"></script> -->
  <script src="<?php echo base_url().'assets/bootstrap/js/bootstrap.bundle.base.js' ?>"></script>
  <!-- <script src="<?php echo base_url ().'assets/popper.js/dist/umd/popper.min.js' ?>"></script> -->
  <script src="<?php echo base_url().'assets/bootstrap/js/bootstrap.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/perfect-scrollbar/dist/perfect-scrollbar.min.js' ?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <script src="<?php echo base_url().'assets/jquery-bar-rating/dist/jquery.barrating.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/chart.js/dist/Chart.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/raphael/raphael.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/morris.js/morris.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/jquery-sparkline/jquery.sparkline.min.js' ?>"></script>
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="<?php echo base_url().'assets/bootstrap/js/bootstrap.bundle.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/off-canvas.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/hoverable-collapse.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/misc.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/settings.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/todolist.js' ?>"></script>
  <script src="<?php echo base_url().'assets/jquery/jquery.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/bootstrap-datepicker.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/file-upload.js' ?>"></script>
  <!-- endinject -->
  