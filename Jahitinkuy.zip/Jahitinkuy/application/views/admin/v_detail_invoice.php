<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Load partials head -->
  <?php $this->load->view('admin/partials/_head.php') ?>
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/dataTables.bootstrap4.min.css' ?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/font-awesome/css/font-awesome.min.css' ?>" />
  <style>
    th{
      padding-right: 0 !important;
    }

    td{
      padding-right: 2px;
    }

    .total{
      background: #21D0C9;
      font-weight: bold;
    }

    .badge{
      background: #21D0C9;
      color: white;
    }
  </style>
</head>
<body class="sidebar-fixed">
  <div class="container-scroller">
    <!-- Load partial navbar -->
    <?php $this->load->view('admin/partials/_navbar.php') ?>
    <!-- end partial navbar -->
    <div class="container-fluid page-body-wrapper">
      <div class="row row-offcanvas row-offcanvas-right">
        <!-- Load partial setting-pannel -->
        <?php $this->load->view('admin/partials/_settings-panel.php') ?>
        <!-- end partial navbar -->

        <!-- Load partial sidebar -->
        <?php $this->load->view('admin/partials/_sidebar.php') ?>
        <!-- end partial sidebar -->
        <div class="content-wrapper">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">Detail Invoice <label class="badge"><?php echo $invoice->id; ?></label></h4> 
              <div class="btn-group mr-2 btn-add-jasa">
                <a href="<?php echo base_url().'index.php/page/invoice' ?>" class="btn btn-sm btn-info"><i class="icon-arrow-left menu-icon"></i> Kembali</a>
              </div>
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                    <table id="order-listing" class="table table-striped sortable-table">
                      <thead>
                        <tr>
                            <th>Id Jasa<i class="mdi mdi-menu-swap"></th>
                            <th>Kategori<i class="mdi mdi-menu-swap"></th>
                            <th>Jenis<i class="mdi mdi-menu-swap"></th>
                            <th>Jumlah<i class="mdi mdi-menu-swap"></th>
                            <th>Harga<i class="mdi mdi-menu-swap"></th>
                            <th>Subtotal<i class="mdi mdi-menu-swap"></th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php 
                            $total = 0;
                            foreach ($pesanan as $o) { 
                            $subtotal = $o->jumlah * $o->harga;
                            $total += $subtotal;
                          ?>
                        <tr>
                            <td><?php echo $o->id_jasa; ?></td>
                            <td><?php echo $o->nama_jasa; ?></td>
                            <td><?php echo $o->jenis; ?></td>
                            <td><?php echo $o->jumlah; ?></td>
                            <td>Rp. <?php echo number_format($o->harga,0,',','.') ?></td>
                            <td>Rp. <?php echo number_format($subtotal,0,',','.') ?></td>
                        </tr>
                        <?php } ?>
                        <tr>
                          <td colspan="5" class="total text-center">Total</td>
                          <td class="total">Rp. <?php echo number_format($total,0,',','.') ?></td>
                        </tr>
                      
                      </tbody>
                    </table>                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!--  Load partial sidebar -->
        <?php $this->load->view('admin/partials/_footer.php') ?>
        <!-- end partial sidebar -->
      </div>
      <!-- row-offcanvas ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- Load partial sidebar -->
  <?php $this->load->view('admin/partials/_js.php') ?>
  <!-- end partial sidebar -->
  <script src="<?php echo base_url().'assets/js/jquery.dataTables.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/dataTables.bootstrap4.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/data-table.js' ?>"></script>

  
</body>

</html>
