<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Load partials head -->
  <?php $this->load->view('admin/partials/_head.php') ?>
</head>
<body class="sidebar-fixed">
  <div class="container-scroller">
    <!-- Load partial navbar -->
    <?php $this->load->view('admin/partials/_navbar.php') ?>
    <!-- end partial navbar -->
    <div class="container-fluid page-body-wrapper">
      <div class="row row-offcanvas row-offcanvas-right">
        <!-- Load partial setting-pannel -->
        <?php $this->load->view('admin/partials/_settings-panel.php') ?>
        <!-- end partial navbar -->

        <!-- Load partial sidebar -->
        <?php $this->load->view('admin/partials/_sidebar.php') ?>
        <!-- end partial sidebar -->
        
        <!-- content-wrapper ends -->
        <!--  Load partial footer -->
        <?php $this->load->view('admin/partials/_footer.php') ?>
        <!-- end partial footer -->
      </div>
      <!-- row-offcanvas ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- Load partial sidebar -->
  <?php $this->load->view('admin/partials/_js.php') ?>
  <!-- end partial sidebar -->
</body>

</html>
