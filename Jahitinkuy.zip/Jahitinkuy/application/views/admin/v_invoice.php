<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Load partials head -->
  <?php $this->load->view('admin/partials/_head.php') ?>
  <link rel="stylesheet" href="<?php echo base_url().'assets/css/dataTables.bootstrap4.min.css' ?>">
  <link rel="stylesheet" href="<?php echo base_url().'assets/font-awesome/css/font-awesome.min.css' ?>" />
  <style>
    th{
      padding-right: 0 !important;
    }

    td{
      padding-right: 2px;
    }
  </style>
</head>
<body class="sidebar-fixed">
  <div class="container-scroller">
    <!-- Load partial navbar -->
    <?php $this->load->view('admin/partials/_navbar.php') ?>
    <!-- end partial navbar -->
    <div class="container-fluid page-body-wrapper">
      <div class="row row-offcanvas row-offcanvas-right">
        <!-- Load partial setting-pannel -->
        <?php $this->load->view('admin/partials/_settings-panel.php') ?>
        <!-- end partial navbar -->

        <!-- Load partial sidebar -->
        <?php $this->load->view('admin/partials/_sidebar.php') ?>
        <!-- end partial sidebar -->
        <div class="content-wrapper">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">Invoice : <?php echo $total ?></h4>
              <div class="row">
                <div class="col-12">
                  <div class="table-responsive">
                    <table id="order-listing" class="table table-striped sortable-table">
                      <thead>
                        <tr>
                            <th>Id Pesanan<i class="mdi mdi-menu-swap"></th>
                            <th>Nama<i class="mdi mdi-menu-swap"></th>
                            <th>Alamat<i class="mdi mdi-menu-swap"></th>
                            <th>Tanggal Pesan<i class="mdi mdi-menu-swap"></th>
                            <th>Batas Bayar<i class="mdi mdi-menu-swap"></th>
                            <th>Status<i class="mdi mdi-menu-swap"></th>
                            <th>Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php foreach ($invoice as $o) { ?>
                        <tr>
                            <td><?php echo $o->id; ?></td>
                            <td><?php echo $o->nm_depan; ?> <?php echo $o->nm_belakang; ?></td>
                            <td><?php echo $o->alamat; ?></td>
                            <td><?php echo $o->tanggal; ?></td>
                            <td><?php echo $o->tenggat; ?></td>
                            <td>
                              <label class="badge badge-info">On hold</label>
                            </td>
                            <td>
                              <?php echo anchor('invoice/detail/'.$o->id, '<button class="btn btn-outline-primary">Detail</button>') ?>
                            </td>
                        </tr>
                      <?php } ?>
                      </tbody>
                    </table>                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!--  Load partial sidebar -->
        <?php $this->load->view('admin/partials/_footer.php') ?>
        <!-- end partial sidebar -->
      </div>
      <!-- row-offcanvas ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- Load partial sidebar -->
  <?php $this->load->view('admin/partials/_js.php') ?>
  <!-- end partial sidebar -->
  <script src="<?php echo base_url().'assets/js/jquery.dataTables.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/dataTables.bootstrap4.min.js' ?>"></script>
  <script src="<?php echo base_url().'assets/js/data-table.js' ?>"></script>

  
</body>

</html>
